import json
import os
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

from acceptance.model import EVENTS, PHASES, STATE_LABELS, reachable_paths
from launcher import default_paths, initialize_config
from main import load_config
from rpc import CodexReader
from runtime import runtime_state
from store import STATES, Store
from titles import DesktopTitleWriter, TitleSynchronizer


class StateContractTests(unittest.TestCase):
    def test_state_names_and_display_order(self):
        contract = json.loads(Path(__file__).with_name("requirements.json").read_text())
        self.assertEqual(contract["states"], [list(item) for item in STATE_LABELS])
        self.assertEqual(list(STATES.items()), list(STATE_LABELS))

    def test_runtime_evidence_table(self):
        samples = (
            ({"type": "active"}, {"status": "inProgress"}, "in_progress"),
            ({"type": "active", "activeFlags": ["waitingOnApproval"]},
             {"status": "inProgress"}, "blocked"),
            ({"type": "active", "activeFlags": ["waitingOnUserInput"]},
             {"status": "inProgress"}, "blocked"),
            ({"type": "systemError"}, {"status": "inProgress"}, "blocked"),
            ({"type": "idle"}, {"status": "failed"}, "blocked"),
            ({"type": "idle"}, {"status": "interrupted"}, "blocked"),
            ({"type": "idle"}, {"status": "completed"}, "review"),
            ({"type": "notLoaded"}, {}, None),
            ({"type": "active"}, {"status": "completed"}, None),
            ({"type": "idle"}, {"status": "inProgress"}, None),
        )
        for status, turn, expected in samples:
            with self.subTest(status=status, turn=turn):
                decision = runtime_state(status, turn)
                self.assertEqual(decision[0] if decision else None, expected)
                self.assertNotIn(
                    decision[0] if decision else None, {"completed", "to_archive"}
                )

    def test_all_abstract_state_edges_match_store(self):
        graph = reachable_paths()
        self.assertEqual(len(graph), 40)
        for model, path in graph:
            for event in EVENTS:
                with self.subTest(path=path, event=event):
                    self.check_trace((*path, event), model.step(event))

    def check_trace(self, events, expected):
        clock = [1000.0]
        with tempfile.TemporaryDirectory() as directory, patch(
            "store.time.time", side_effect=lambda: clock[0]
        ):
            store = Store(directory)
            try:
                store.discover([{
                    "id": "contract-thread", "name": "验收会话",
                    "cwd": "/fixture", "updatedAt": 1,
                }])
                store.observe("contract-thread", {
                    "id": "round-one", "status": "inProgress",
                    "userItems": ["input-one"], "startedAt": 1001,
                })
                self.runtime_event(store, "running", clock)
                for event in events:
                    clock[0] += 10
                    row = store.sessions()[0]
                    if event.startswith("manual:"):
                        store.set_state(
                            row["id"], event.split(":", 1)[1], "人工备注",
                            row["version"], row["inputVersion"],
                        )
                    elif event == "restart":
                        store.close()
                        store = Store(directory)
                    elif event == "view":
                        store.sessions()
                    else:
                        self.runtime_event(store, event, clock)
                actual = store.sessions()[0]
                self.assertEqual(
                    {key: actual[key] for key in ("state", "manual", "note", "version")},
                    {
                        "state": expected.state, "manual": expected.manual,
                        "note": expected.note, "version": expected.version,
                    },
                )
            finally:
                store.close()

    def runtime_event(self, store, phase, clock):
        status = {"type": "active"}
        turn = {
            "id": "round-one", "status": "inProgress", "startedAt": 1001,
        }
        if phase in {"approval", "input"}:
            status["activeFlags"] = [
                "waitingOnApproval" if phase == "approval" else "waitingOnUserInput"
            ]
        elif phase == "error":
            status["type"] = "systemError"
        elif phase == "finished":
            status["type"] = "idle"
            turn.update(status="completed", completedAt=clock[0])
        self.assertIn(phase, PHASES)
        store.observe_runtime("contract-thread", status, turn, 1000)


class MetadataDouble:
    def __init__(self):
        self.names = {"first": "第一会话", "second": "第二会话"}
        self.writes = []
        self.finished = threading.Event()

    def writer(self, *_):
        return self

    def current_title(self, identifier):
        return self.names[identifier]

    def rename(self, identifier, title):
        self.names[identifier] = title
        self.writes.append((identifier, title))
        self.finished.set()

    def close(self):
        return


class IsolationContractTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.store = Store(self.directory.name, sync_titles=True)
        self.store.discover([
            {"id": identifier, "name": title, "updatedAt": 1}
            for identifier, title in (("first", "第一会话"), ("second", "第二会话"))
        ])
        self.native = MetadataDouble()

    def tearDown(self):
        self.store.close()
        self.directory.cleanup()

    def test_view_and_single_chat_change_are_isolated(self):
        with tempfile.TemporaryDirectory() as other_directory:
            other = Store(other_directory, sync_titles=True)
            other.discover([{"id": "first", "name": "另一数据库", "updatedAt": 1}])
            try:
                before_other = other.sessions()
                before_second = self.store.sessions()[1]
                sync = TitleSynchronizer(
                    {"desktop_socket": "/fixture", "rpc_timeout_seconds": 1},
                    self.store, self.native.writer,
                )
                self.store.title_callback = sync.sync
                self.store.set_state("first", "to_archive", "保留人工备注", 0)
                after = self.store.sessions()
                self.assertEqual(after[1], before_second)
                self.assertEqual(other.sessions(), before_other)
                self.assertEqual(self.native.names["second"], "第二会话")
                self.assertEqual(self.native.writes, [("first", "[待归档] 第一会话")])
                before = self.store.sessions()
                self.assertEqual(self.store.sessions(), before)
                self.assertEqual(len(self.native.writes), 1)
                change = self.store.database.execute(
                    "SELECT thread_id,state,note FROM changes"
                ).fetchall()
                self.assertEqual(
                    [tuple(row) for row in change],
                    [("first", "to_archive", "保留人工备注")],
                )
            finally:
                other.close()

    def test_title_queue_failure_rolls_back_state_and_audit(self):
        before = self.store.sessions()
        self.store.title_callback = lambda _: self.fail("Uncommitted callback ran")
        with patch.object(self.store, "_queue_title", side_effect=RuntimeError("injected")):
            with self.assertRaises(RuntimeError):
                self.store.set_state("first", "review", "备注", 0)
        self.assertEqual(self.store.sessions(), before)
        self.assertEqual(self.store.pending_titles(), [])
        self.assertEqual(
            self.store.database.execute("SELECT count(*) FROM changes").fetchone()[0], 0
        )

    def test_committed_pending_title_recovers_after_callback_interruption(self):
        def interrupted_callback(_):
            raise SystemExit("simulate interruption after commit")
        self.store.title_callback = interrupted_callback
        with self.assertRaises(SystemExit):
            self.store.set_state("first", "to_archive", "保留备注", 0)
        self.store.close()
        self.store = Store(self.directory.name, sync_titles=True)
        sync = TitleSynchronizer(
            {"desktop_socket": "/fixture", "rpc_timeout_seconds": 1, "poll_seconds": 0.05},
            self.store, self.native.writer,
        )
        worker = threading.Thread(target=sync.run, daemon=True)
        worker.start()
        try:
            self.assertTrue(self.native.finished.wait(2))
        finally:
            sync.stop.set()
            sync.wake.set()
            worker.join(2)
        self.assertFalse(worker.is_alive())
        self.assertEqual(self.store.pending_titles(), [])
        row = self.store.sessions()[0]
        self.assertEqual((row["state"], row["note"]), ("to_archive", "保留备注"))
        self.assertEqual(self.native.writes, [("first", "[待归档] 第一会话")])

    def test_native_adapter_reads_full_name_and_scopes_metadata_write(self):
        writer = DesktopTitleWriter.__new__(DesktopTitleWriter)
        name = "🧪 [项目] 我手动改过的标题" + "完整" * 350
        with patch.object(writer, "call", return_value={"thread": {"name": name}}) as call:
            self.assertEqual(writer.current_title("first"), name)
            call.assert_called_once_with("thread/read", {
                "threadId": "first", "includeTurns": False,
            })
        with patch.object(writer, "call") as call:
            writer.rename("first", "[待审阅] " + name)
            call.assert_called_once_with("thread/name/set", {
                "threadId": "first", "name": "[待审阅] " + name,
            })

    def test_discovery_requests_only_the_declared_scope(self):
        reader = CodexReader.__new__(CodexReader)
        with patch.object(reader, "call", return_value={"data": []}) as call:
            self.assertEqual(reader.list_threads(), ([], True))
            method, parameters = call.call_args.args
            self.assertEqual(method, "thread/list")
            self.assertEqual(parameters["sourceKinds"], ["cli", "vscode", "appServer"])
            self.assertEqual(parameters["modelProviders"], [])
            self.assertFalse(parameters["archived"])
            self.assertTrue(parameters["useStateDbOnly"])

    def test_disabled_title_sync_saves_without_native_writes(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(directory, sync_titles=False)
            sync = TitleSynchronizer({}, store, self.native.writer)
            store.title_callback = sync.sync
            try:
                store.discover([{"id": "first", "name": "第一会话", "updatedAt": 1}])
                store.set_state("first", "completed", "保留备注", 0)
                self.assertEqual(store.sessions()[0]["state"], "completed")
                self.assertEqual(store.pending_titles(), [])
                self.assertEqual(self.native.writes, [])
                self.assertEqual(self.native.names["first"], "第一会话")
            finally:
                store.close()


class ConfigurationContractTests(unittest.TestCase):
    def test_paths_come_from_environment_and_relative_data_uses_config_directory(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config_home = root / "profile/config"
            data_home = root / "profile/data"
            with patch.dict(os.environ, {
                "XDG_CONFIG_HOME": str(config_home), "XDG_DATA_HOME": str(data_home),
            }, clear=True):
                config_path, data_path = default_paths()
                self.assertEqual(config_path, config_home / "codex-session-board/config.json")
                self.assertEqual(data_path, data_home / "codex-session-board")
                initialize_config(config_path, data_path)
                self.assertEqual(load_config(config_path)["data_dir"], str(data_path.resolve()))
                override = root / "custom/config.json"
                with patch.dict(os.environ, {"CODEX_SESSION_BOARD_CONFIG": str(override)}):
                    self.assertEqual(default_paths()[0], override)
            relative = root / "deployment/config.json"
            relative.parent.mkdir()
            relative.write_text(json.dumps({"data_dir": "../persistent"}))
            self.assertEqual(load_config(relative)["data_dir"], str(root / "persistent"))
