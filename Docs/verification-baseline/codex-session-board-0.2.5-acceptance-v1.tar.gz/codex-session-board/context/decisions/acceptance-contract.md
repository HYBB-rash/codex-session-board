# Portable acceptance and completion gate

Date: 2026-11-06
Source: user request to turn the agreed plugin requirements into individually
verifiable criteria for another project and its development Agent.

Keep numbered requirements independent from implementation bindings.
Distinguish explicit user requirements, existing engineering protections and
delivery requirements. The initial baseline has 31 requirements.

Reuse the existing 69 tests and add finite-state, isolation, configuration,
transaction-boundary, packaging and verifier checks. A separate reference model
checks 40 abstract states and 520 transitions against the real store.
This is bounded executable acceptance, not a proof of the whole desktop system.

The default command checks full acceptance. Automatic-only success is useful
during development but cannot establish completion. Missing, skipped or failed
checks and absent target-environment evidence prevent the complete result.
Evidence is bound to the requirements and implementation fingerprints.
The verifier validates records and artifact hashes; evidence contents still
need review by a person or an Agent able to operate the target application.

Do not use old Python tests to accept a replacement implementation.
Port the tests and replace bindings or the JSON test adapter while preserving
requirement identifiers. Requirement changes need an explicit user decision.

The migration archive includes portable source, assets and acceptance files.
Its context state is reset to a handoff. Existing machine configuration,
runtime databases, conversation screenshots and execution history are excluded.
