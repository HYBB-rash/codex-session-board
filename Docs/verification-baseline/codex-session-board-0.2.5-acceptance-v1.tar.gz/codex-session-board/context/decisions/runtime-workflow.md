# Conversation work status

Date: 2026-11-06
Source: the user's final summary in this chat.

Beginning or resuming actual AI execution automatically sets in-progress.
Execution paused for approval or tool input, failed requests that stop the turn,
interruption and runtime system errors automatically set blocked.
Normal turn completion automatically sets review, where the user checks results.
Turn completion does not establish that the whole task has passed acceptance.

The user manually selects to-archive followed by completed as the closing order,
and can adjust other states. This order does not impose transition restrictions.
Opening a chat alone does not change state. A later genuine execution phase can
replace an earlier manual choice; duplicate observations of an existing phase
cannot. To-archive remains a marker and does not invoke Codex archive.

The initial suggestion that normal completion should remain in-progress was
superseded by the user's final summary. Automated classification uses runtime
evidence rather than interpreting assistant claims about task completion.
