# Native title projection

Date: 2026-11-06
Source: user request to implement title renaming after state changes.

Manual state saves attempt native title synchronization immediately, and
automatic execution transitions do the same once observed. The title format
is [状态] followed by its existing body. Replace only known leading state
markers, never append more markers or rewrite the rest of the name.

Read the latest full native title on each attempt, not the board's truncated
display title. Native writes are limited to thread/name/set on the existing
desktop authority. No resume, message dispatch or archive side effects.

State remains authoritative when a title write fails. Persist desired title
work atomically with state, retry in the background and reject superseded
versions. An enabled-since epoch prevents old completed turns discovered
after installation from causing historical batch renames.
