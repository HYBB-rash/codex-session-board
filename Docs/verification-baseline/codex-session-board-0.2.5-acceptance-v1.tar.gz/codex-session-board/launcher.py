import argparse
import fcntl
import json
import os
import signal
import sqlite3
import subprocess
import sys
import time
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

from main import BUILD_ID, config_id, load_config


def default_paths():
    config_home = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    data_home = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share"))
    config_file = Path(os.environ.get(
        "CODEX_SESSION_BOARD_CONFIG", config_home / "codex-session-board/config.json"
    ))
    return config_file, data_home / "codex-session-board"


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temporary.replace(path)


def initialize_config(config_path, data_dir, source=None, open_command=None):
    if config_path.exists():
        if source:
            raise ValueError("插件配置已经存在，不会覆盖。请使用 --config 指定其他配置文件")
        return
    config = load_config(source) if source else {}
    source_dir = Path(config["data_dir"]) if source else None
    data_dir.mkdir(parents=True, exist_ok=True)
    created_database = None
    try:
        if source_dir and (source_dir / "status.sqlite3").exists():
            target = data_dir / "status.sqlite3"
            if target.exists():
                raise ValueError("目标状态库已经存在，不会覆盖")
            source_database = sqlite3.connect(
                (source_dir / "status.sqlite3").resolve().as_uri() + "?mode=ro", uri=True
            )
            target_database = None
            try:
                target_database = sqlite3.connect(target)
                created_database = target
                source_database.backup(target_database)
            finally:
                source_database.close()
                if target_database:
                    target_database.close()
        config["data_dir"] = str(data_dir.resolve())
        if open_command:
            config["open_command"] = open_command
        save_json(config_path, config)
    except Exception:
        if created_database:
            created_database.unlink(missing_ok=True)
        raise


def probe(url):
    try:
        with urlopen(url + "/api/info", timeout=1) as response:
            value = json.load(response)
        return value if isinstance(value, dict) else None
    except (URLError, OSError, ValueError):
        return None


def matches(info, config):
    return bool(
        info and info.get("app") == "codex-session-board"
        and info.get("dataDir") == config["data_dir"]
    )


def process_alive(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    stat = Path(f"/proc/{pid}/stat")
    if stat.exists():
        try:
            return stat.read_text().rsplit(")", 1)[1].split()[0] != "Z"
        except FileNotFoundError:
            return False
    return True


def ensure_running(config_path):
    config = load_config(config_path)
    if config["port"] == 0:
        raise ValueError("插件启动器需要配置固定端口，port 不能为 0")
    data_dir = Path(config["data_dir"])
    data_dir.mkdir(parents=True, exist_ok=True)
    url = f"http://127.0.0.1:{config['port']}"
    with (data_dir / "launch.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        record_path = data_dir / "server.json"
        if record_path.exists():
            record = json.loads(record_path.read_text())
            previous = probe(record["url"])
            if matches(previous, config) and previous.get("pid") == record["pid"]:
                if record["url"] != url:
                    raise ValueError("同一状态库仍有服务运行，请先 --stop 再更换端口")
            elif previous is None and process_alive(record["pid"]):
                raise ValueError("已有受管进程仍存活但暂不可访问，不会重复启动")
        info = probe(url)
        if info is not None:
            if not matches(info, config):
                raise ValueError("端口已由其他服务或数据目录占用，请调整插件配置")
            if info.get("build") != BUILD_ID:
                raise ValueError("已有旧版看板运行，请先用启动器 --stop 停止，再重新打开")
            if info.get("configId") != config_id(config):
                raise ValueError("运行服务的配置已变化，请先 --stop 再重新打开")
            return {"url": url, "running": True, "started": False}
        log_path = data_dir / "server.log"
        with log_path.open("ab") as log:
            process = subprocess.Popen(
                [
                    sys.executable, str(Path(__file__).with_name("main.py")),
                    "--config", str(config_path.resolve()),
                ],
                stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                start_new_session=True,
            )
        for _ in range(80):
            info = probe(url)
            if matches(info, config) and info.get("pid") == process.pid:
                save_json(data_dir / "server.json", {"pid": process.pid, "url": url})
                return {"url": url, "running": True, "started": True}
            if process.poll() is not None:
                raise ValueError(f"看板启动失败，请查看 {log_path}")
            time.sleep(0.1)
        raise ValueError(f"看板启动尚未确认，请查看 {log_path}")


def stop_running(config_path):
    config = load_config(config_path)
    record_path = Path(config["data_dir"]) / "server.json"
    if not record_path.exists():
        raise ValueError("没有找到本启动器创建的服务记录")
    with (Path(config["data_dir"]) / "launch.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        record = json.loads(record_path.read_text())
        info = probe(record["url"])
        if info is None:
            if process_alive(record["pid"]):
                raise ValueError("受管进程仍存活，但无法核验服务身份")
            return {"running": False, "stopped": False}
        if not matches(info, config) or info.get("pid") != record["pid"]:
            raise ValueError("服务身份与启动记录不一致，不会停止它")
        os.kill(record["pid"], signal.SIGINT)
        for _ in range((config["rpc_timeout_seconds"] + 10) * 10):
            if not process_alive(record["pid"]):
                return {"running": False, "stopped": True}
            time.sleep(0.1)
        raise ValueError("服务进程退出尚未确认")


def main():
    parser = argparse.ArgumentParser(description="启动 Codex 会话看板插件")
    parser.add_argument("--config", type=Path)
    parser.add_argument("--import-config", type=Path)
    parser.add_argument("--open-command", nargs="+")
    parser.add_argument("--stop", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    os.umask(0o077)
    default_config, data_dir = default_paths()
    config_path = args.config or default_config
    try:
        if args.stop:
            result = stop_running(config_path)
        else:
            initialize_config(
                config_path, data_dir, args.import_config, args.open_command
            )
            result = ensure_running(config_path)
        result["config"] = str(config_path.resolve())
        print(json.dumps(result, ensure_ascii=False) if args.json else result.get("url", "已停止"))
    except (OSError, ValueError, KeyError) as error:
        print(json.dumps({"error": str(error)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1) from error


if __name__ == "__main__":
    main()
