import argparse
import hashlib
import json
import os
import secrets
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from rpc import CodexReader, RpcRequestError
from navigation import open_conversation
from store import STATES, Store
from runtime import RuntimeObserver
from titles import TitleSynchronizer


BUILD_ID = hashlib.sha256(b"".join(
    Path(__file__).with_name(name).read_bytes()
    for name in ("main.py", "index.html", "store.py", "rpc.py", "navigation.py", "runtime.py", "titles.py")
)).hexdigest()[:16]


DEFAULTS = {
    "codex_command": ["codex", "app-server", "--stdio"],
    "data_dir": ".runtime",
    "port": 8767,
    "poll_seconds": 30,
    "rpc_timeout_seconds": 20,
    "page_size": 100,
    "max_pages": 100,
    "history_per_poll": 20,
    "host_id": "local",
    "open_command": ["open"] if sys.platform == "darwin" else ["xdg-open"],
    "desktop_socket": os.environ.get("CODEX_LINUX_APP_SERVER_BRIDGE_SOCKET", ""),
    "runtime_poll_seconds": 2,
    "sync_titles": True,
}


def config_id(config):
    return hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()[:16]


def load_config(path):
    path = Path(path).resolve() if path else None
    config = dict(DEFAULTS)
    if path:
        config.update(json.loads(path.read_text()))
    base = path.parent if path else Path(__file__).resolve().parent
    config["data_dir"] = str((base / config["data_dir"]).resolve())
    for key in ("codex_command", "open_command"):
        command = config[key]
        if not isinstance(command, list) or not command or not all(
            isinstance(part, str) and part for part in command
        ):
            raise ValueError(f"{key} 必须是非空命令参数数组")
    if not isinstance(config["host_id"], str) or not config["host_id"]:
        raise ValueError("host_id 必须是非空文本")
    if not isinstance(config["desktop_socket"], str):
        raise ValueError("desktop_socket 必须是路径文本")
    if type(config["sync_titles"]) is not bool:
        raise ValueError("sync_titles 必须为布尔值")
    for key in ("poll_seconds", "runtime_poll_seconds", "rpc_timeout_seconds", "page_size", "max_pages", "history_per_poll"):
        if type(config[key]) is not int or config[key] < 1:
            raise ValueError(f"{key} 必须为正整数")
    if type(config["port"]) is not int or not 0 <= config["port"] <= 65535:
        raise ValueError("port 必须在 0 到 65535 之间")
    return config


class Observer:
    def __init__(self, config, store):
        self.config = config
        self.store = store
        self.stop = threading.Event()
        self.trigger = threading.Event()
        self.lock = threading.Lock()
        self.health = {
            "lastScanAt": None, "lastSuccessAt": None, "error": None,
            "scanComplete": False, "refreshing": False, "discovered": 0,
            "runtimeVerified": False,
            "runtimeError": None, "runtimeLastAt": None,
        }

    def snapshot(self):
        with self.lock:
            return dict(self.health)

    def update(self, **values):
        with self.lock:
            self.health.update(values)

    def scan(self, reader):
        self.update(refreshing=True, lastScanAt=time.time())
        try:
            threads, complete = reader.list_threads(
                self.config["page_size"], self.config["max_pages"]
            )
            self.store.discover(threads)
            current_ids = {thread["id"] for thread in threads}
            candidates = [
                row for row in self.store.pending() if row["id"] in current_ids
            ]
            changed = sorted(
                [
                    row for row in candidates
                    if row["observed_revision"] is not None
                    and row["updated_at"] > row["observed_revision"]
                    and not row["observation_error"]
                ],
                key=lambda row: row["updated_at"], reverse=True,
            )
            quota = self.config["history_per_poll"]
            selected = changed[:quota // 2]
            selected_ids = {row["id"] for row in selected}
            selected.extend(
                row for row in candidates if row["id"] not in selected_ids
            )
            selected = selected[:quota]
            for row in selected:
                if self.stop.is_set():
                    break
                try:
                    self.store.observe(row["id"], reader.latest_turn(row["id"]))
                except RpcRequestError as error:
                    self.store.observe(row["id"], {}, str(error))
                except RuntimeError as error:
                    self.store.observe(row["id"], {}, str(error))
                    raise
            self.update(
                lastSuccessAt=time.time(), error=None,
                scanComplete=complete, discovered=len(threads),
            )
        except (RuntimeError, OSError, ValueError, KeyError) as error:
            self.update(error=str(error), scanComplete=False)
            raise
        finally:
            self.update(refreshing=False)

    def run(self):
        reader = None
        while not self.stop.is_set():
            self.trigger.clear()
            try:
                if reader is None:
                    reader = CodexReader(
                        self.config["codex_command"],
                        self.config["rpc_timeout_seconds"],
                    )
                self.scan(reader)
            except (RuntimeError, OSError, ValueError, KeyError) as error:
                self.update(error=str(error), refreshing=False, scanComplete=False)
                if reader:
                    reader.close()
                    reader = None
            if self.stop.is_set():
                break
            self.trigger.wait(self.config["poll_seconds"])
        if reader:
            reader.close()


def make_handler(store, observer, opener=open_conversation):
    token = secrets.token_urlsafe(24)
    html = Path(__file__).with_name("index.html").read_text()
    html = html.replace("__CSRF_TOKEN__", token).encode()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format_string, *args):
            return

        def respond(self, code, body, content_type="application/json; charset=utf-8"):
            data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.end_headers()
            self.wfile.write(data)

        def valid_host(self):
            return self.headers.get("Host") == f"127.0.0.1:{self.server.server_port}"

        def do_GET(self):
            if not self.valid_host():
                return self.respond(403, {"error": "无效访问地址"})
            path = urlsplit(self.path).path
            if path == "/":
                return self.respond(200, html, "text/html; charset=utf-8")
            if path == "/api/sessions":
                return self.respond(200, {
                    "states": STATES, "sessions": store.sessions(),
                    "health": observer.snapshot(),
                })
            if path == "/api/info":
                return self.respond(200, {
                    "app": "codex-session-board",
                    "version": "0.2.5",
                    "dataDir": observer.config["data_dir"],
                    "build": BUILD_ID,
                    "pid": os.getpid(),
                    "configId": config_id(observer.config),
                })
            self.respond(404, {"error": "页面不存在"})

        def do_POST(self):
            if not self.valid_host() or self.headers.get("X-CSRF-Token") != token:
                return self.respond(403, {"error": "请从本地面板操作"})
            origin = self.headers.get("Origin")
            if origin and origin != f"http://127.0.0.1:{self.server.server_port}":
                return self.respond(403, {"error": "无效来源"})
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 12000:
                    raise ValueError("请求大小无效")
                body = json.loads(self.rfile.read(length))
                if not isinstance(body, dict):
                    raise ValueError("请求格式无效")
                path = urlsplit(self.path).path
                if path == "/api/open":
                    if not store.contains(body.get("id")):
                        raise ValueError("会话不在本地看板中")
                    url = opener(body["id"], observer.config)
                    return self.respond(200, {"ok": True, "url": url})
                if path == "/api/state":
                    if type(body.get("version")) is not int:
                        raise ValueError("缺少状态版本")
                    if "inputVersion" in body and type(body["inputVersion"]) is not int:
                        raise ValueError("输入版本格式无效")
                    store.set_state(
                        body["id"], body["state"], body.get("note", ""),
                        body["version"], body.get("inputVersion"),
                    )
                    pending = store.pending_titles(body["id"])
                    return self.respond(200, {
                        "ok": True, "titleEnabled": store.sync_titles, "titlePending": bool(pending),
                        "titleError": pending[0]["error"] if pending else None,
                    })
                if path == "/api/refresh":
                    observer.trigger.set()
                    return self.respond(202, {"ok": True})
                self.respond(404, {"error": "接口不存在"})
            except (ValueError, KeyError, TypeError) as error:
                self.respond(400, {"error": str(error)})

    return Handler


def main():
    parser = argparse.ArgumentParser(description="本地 Codex 会话状态面板")
    parser.add_argument("--config", help="JSON 配置文件")
    parser.add_argument("--once", action="store_true", help="扫描一次并输出摘要")
    args = parser.parse_args()
    config = load_config(args.config)
    store = Store(config["data_dir"], sync_titles=config["sync_titles"])
    title_sync = TitleSynchronizer(config, store) if config["sync_titles"] else None
    if title_sync:
        store.title_callback = title_sync.sync
    observer = Observer(config, store)
    runtime = RuntimeObserver(config, store, observer) if config["desktop_socket"] else None
    if args.once:
        reader = None
        try:
            reader = CodexReader(config["codex_command"], config["rpc_timeout_seconds"])
            observer.scan(reader)
            if runtime:
                from runtime import DesktopReader
                desktop = DesktopReader(config["desktop_socket"], config["rpc_timeout_seconds"])
                try:
                    runtime.scan(desktop)
                finally:
                    desktop.close()
            print(json.dumps({
                "health": observer.snapshot(),
                "total": len(store.sessions()),
            }, ensure_ascii=False, indent=2))
        finally:
            if reader:
                reader.close()
            store.close()
        return
    server = ThreadingHTTPServer(("127.0.0.1", config["port"]), make_handler(store, observer))
    worker = threading.Thread(target=observer.run, daemon=True)
    worker.start()
    runtime_worker = threading.Thread(target=runtime.run, daemon=True) if runtime else None
    if runtime_worker:
        runtime_worker.start()
    title_worker = threading.Thread(target=title_sync.run, daemon=True) if title_sync else None
    if title_worker:
        title_worker.start()
    print(f"http://127.0.0.1:{server.server_port}", flush=True)
    try:
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        pass
    finally:
        observer.stop.set()
        if runtime:
            runtime.stop.set()
        if title_sync:
            title_sync.stop.set()
            title_sync.wake.set()
        observer.trigger.set()
        server.server_close()
        worker.join(timeout=config["rpc_timeout_seconds"] + 5)
        if runtime_worker:
            runtime_worker.join(timeout=config["rpc_timeout_seconds"] + 5)
        if title_worker:
            title_worker.join(timeout=config["rpc_timeout_seconds"] + 5)
        if not any(item and item.is_alive() for item in (worker, runtime_worker, title_worker)):
            store.close()


if __name__ == "__main__":
    main()
