import argparse
import base64
import json
import os
import re
import sys
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from launcher import default_paths, ensure_running, initialize_config


ROOT = Path(__file__).resolve().parent
RESOURCE = "ui://session-board/index.html"
MIME_TYPE = "text/html;profile=mcp-app"
VERSION = "0.2.5"


def tools():
    icon = base64.b64encode((ROOT / "assets/board.svg").read_bytes()).decode()
    definitions = [
        ("board_view", "会话看板", "打开本地会话看板，不发送消息。", {}, [], True),
        ("board_snapshot", "读取会话状态", "读取现有本地会话和工作状态。", {}, [], True),
        ("board_update", "确认工作状态", "保存用户选择的工作状态和备注。", {
            "id": {"type": "string"},
            "state": {"type": ["string", "null"]},
            "note": {"type": "string", "maxLength": 2000},
            "version": {"type": "integer", "minimum": 0},
            "inputVersion": {"type": "integer", "minimum": 0},
        }, ["id", "state", "version", "inputVersion"], False),
        ("board_open", "打开已有会话", "跳转到已有会话，不发送消息。", {
            "id": {"type": "string"},
        }, ["id"], True),
        ("board_refresh", "重新发现", "刷新本地会话列表。", {}, [], False),
    ]
    result = []
    for name, title, description, properties, required, read_only in definitions:
        meta = {"ui": {"visibility": ["app"]}}
        if name == "board_view":
            meta = {
                "ui": {"resourceUri": RESOURCE, "visibility": ["app", "model"]},
                "openai/ui": {"entrypoints": [{"type": "global"}]},
            }
        result.append({
            "name": name, "title": title, "description": description,
            "inputSchema": {
                "type": "object", "properties": properties,
                "required": required, "additionalProperties": False,
            },
            "annotations": {
                "readOnlyHint": read_only, "destructiveHint": False,
                "openWorldHint": False,
            },
            "icons": [{"src": "data:image/svg+xml;base64," + icon, "mimeType": "image/svg+xml"}],
            "_meta": meta,
        })
    return result


def resource():
    html = (ROOT / "index.html").read_text().replace("__CSRF_TOKEN__", "")
    bridge = (ROOT / "assets/app-bridge.js").read_text().replace("</script", "<\\/script")
    html = html.replace("<script>", "<script>" + bridge + "</script>\n<script>", 1)
    return {
        "uri": RESOURCE, "mimeType": MIME_TYPE, "text": html,
        "_meta": {"ui": {
            "prefersBorder": False,
            "csp": {"connectDomains": [], "resourceDomains": [], "frameDomains": []},
        }, "openai/ui": {
            "preferredDisplayMode": "fullscreen",
            "availableDisplayModes": ["inline", "fullscreen"],
        }},
    }


class BoardBackend:
    def __init__(self, config_path=None):
        default_config, self.data_dir = default_paths()
        self.config_path = config_path or default_config

    def request(self, path, body=None):
        initialize_config(self.config_path, self.data_dir)
        url = ensure_running(self.config_path)["url"]
        headers = {}
        if body is not None:
            with urlopen(url, timeout=5) as response:
                page = response.read().decode()
            token = re.search(r'const csrf = "([^"]+)"', page)
            if not token:
                raise ValueError("无法读取本地服务令牌，请重新打开看板")
            headers = {"Content-Type": "application/json", "X-CSRF-Token": token[1]}
        payload = json.dumps(body).encode() if body is not None else None
        request = Request(url + path, data=payload, headers=headers)
        try:
            with urlopen(request, timeout=8) as response:
                return json.load(response)
        except HTTPError as error:
            with error:
                try:
                    detail = json.load(error).get("error", "看板操作失败")
                except ValueError:
                    detail = "看板操作失败"
            raise ValueError(detail) from error

    def call(self, name, arguments):
        if name == "board_view":
            return {"ready": True}
        if name == "board_snapshot":
            return self.request("/api/sessions")
        paths = {
            "board_update": "/api/state",
            "board_open": "/api/open",
            "board_refresh": "/api/refresh",
        }
        if name not in paths:
            raise ValueError("未知看板工具")
        return self.request(paths[name], arguments)


def dispatch(method, params, backend):
    if method == "initialize":
        return {
            "protocolVersion": params.get("protocolVersion", "2025-06-18"),
            "capabilities": {"tools": {}, "resources": {}},
            "serverInfo": {"name": "codex-session-board", "version": VERSION},
            "instructions": "本地会话看板。界面操作不发送消息，不执行或归档任务。",
        }
    if method == "ping":
        return {}
    if method == "tools/list":
        return {"tools": tools()}
    if method == "resources/list":
        return {"resources": [{
            "uri": RESOURCE, "name": "会话看板", "mimeType": MIME_TYPE,
        }]}
    if method == "resources/templates/list":
        return {"resourceTemplates": []}
    if method == "resources/read":
        if params.get("uri") != RESOURCE:
            raise ValueError("未知界面资源")
        return {"contents": [resource()]}
    if method == "tools/call":
        try:
            result = backend.call(params["name"], params.get("arguments", {}))
            return {
                "content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}],
                "structuredContent": result,
            }
        except (OSError, ValueError, KeyError, TypeError) as error:
            return {"isError": True, "content": [{"type": "text", "text": str(error)}]}
    raise KeyError(method)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path)
    args = parser.parse_args()
    os.umask(0o077)
    backend = BoardBackend(args.config)
    for line in sys.stdin:
        request_id = None
        try:
            request = json.loads(line)
            if not isinstance(request, dict) or "id" not in request:
                continue
            request_id = request["id"]
            result = dispatch(request.get("method"), request.get("params") or {}, backend)
            response = {"jsonrpc": "2.0", "id": request_id, "result": result}
        except KeyError as error:
            response = {
                "jsonrpc": "2.0", "id": request_id,
                "error": {"code": -32601, "message": f"Unknown method: {error}"},
            }
        except (OSError, ValueError, TypeError) as error:
            response = {
                "jsonrpc": "2.0", "id": request_id,
                "error": {"code": -32602, "message": str(error)},
            }
        print(json.dumps(response, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
