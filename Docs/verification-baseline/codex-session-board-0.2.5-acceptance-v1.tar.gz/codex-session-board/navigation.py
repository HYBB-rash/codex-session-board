import subprocess
import threading
from urllib.parse import urlencode
from uuid import UUID


def conversation_url(thread_id, host_id="local"):
    if not isinstance(thread_id, str):
        raise ValueError("无效会话标识")
    try:
        canonical = str(UUID(thread_id))
    except ValueError as error:
        raise ValueError("无效会话标识") from error
    if canonical != thread_id:
        raise ValueError("无效会话标识")
    if not isinstance(host_id, str) or not host_id:
        raise ValueError("缺少 Codex 主机标识")
    return f"codex://threads/{canonical}?" + urlencode({"hostId": host_id})


def open_conversation(thread_id, config):
    url = conversation_url(thread_id, config["host_id"])
    command = config["open_command"]
    try:
        process = subprocess.Popen(
            [*command, url],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError as error:
        raise ValueError("无法启动配置的 Codex 客户端，请检查 open_command") from error
    try:
        status = process.wait(timeout=1)
    except subprocess.TimeoutExpired:
        threading.Thread(target=process.wait, daemon=True).start()
        status = None
    if status not in (None, 0):
        raise ValueError("Codex 客户端未接受跳转请求")
    return url
