import json
import queue
import subprocess
import threading


class RpcError(RuntimeError):
    pass


class RpcRequestError(RpcError):
    pass


class CodexReader:
    METHODS = {"initialize", "thread/list", "thread/turns/list"}

    def __init__(self, command, timeout=20):
        self.timeout = timeout
        self.messages = queue.Queue()
        self.request_id = 0
        self.process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            bufsize=1,
        )
        self.reader = threading.Thread(target=self._read, daemon=True)
        self.reader.start()
        try:
            self.call("initialize", {
                "clientInfo": {"name": "local_session_status", "version": "0.1.0"}
            })
            self._send({"method": "initialized", "params": {}})
        except Exception:
            self.close()
            raise

    def _read(self):
        try:
            for line in self.process.stdout:
                try:
                    message = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if "id" in message:
                    self.messages.put(message)
        finally:
            self.messages.put(None)

    def _send(self, message):
        try:
            self.process.stdin.write(json.dumps(message) + "\n")
            self.process.stdin.flush()
        except (BrokenPipeError, OSError) as error:
            raise RpcError("Codex 读取连接已关闭") from error

    def call(self, method, params):
        if method not in self.METHODS:
            raise RpcError("此读取器不允许修改 Codex 会话")
        self.request_id += 1
        request_id = self.request_id
        self._send({"id": request_id, "method": method, "params": params})
        while True:
            try:
                message = self.messages.get(timeout=self.timeout)
            except queue.Empty as error:
                raise RpcError(f"读取 {method} 超时") from error
            if message is None:
                raise RpcError("Codex 读取连接已断开")
            if message.get("id") != request_id:
                continue
            if "error" in message:
                details = message["error"]
                raise RpcRequestError(f"{method}: {details.get('message', '请求失败')}")
            return message["result"]

    def close(self):
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=3)
        self.reader.join(timeout=1)
        self.process.stdin.close()
        self.process.stdout.close()

    def list_threads(self, page_size=100, max_pages=100):
        threads = {}
        cursor = None
        seen_cursors = set()
        for _ in range(max_pages):
            result = self.call("thread/list", {
                "limit": page_size,
                "cursor": cursor,
                "sortKey": "updated_at",
                "sortDirection": "desc",
                "modelProviders": [],
                "sourceKinds": ["cli", "vscode", "appServer"],
                "archived": False,
                "useStateDbOnly": True,
            })
            for thread in result["data"]:
                threads.setdefault(thread["id"], thread)
            cursor = result.get("nextCursor")
            if not cursor:
                return list(threads.values()), True
            if cursor in seen_cursors:
                raise RpcError("会话分页游标重复，本次发现未完成")
            seen_cursors.add(cursor)
        return list(threads.values()), False

    def latest_turn(self, thread_id):
        result = self.call("thread/turns/list", {
            "threadId": thread_id,
            "limit": 1,
            "sortDirection": "desc",
            "itemsView": "summary",
        })
        turns = result.get("data", [])
        return summarize_turn(turns[0]) if turns else {}


def summarize_turn(turn):
    items = turn.get("items", [])
    return {
        "id": turn["id"],
        "status": turn.get("status"),
        "startedAt": turn.get("startedAt"),
        "completedAt": turn.get("completedAt"),
        "userItems": sorted(
            item["id"] for item in items if item.get("type") == "userMessage"
        ),
        "hasFinal": any(
            item.get("type") == "agentMessage"
            and item.get("phase") == "final_answer"
            for item in items
        ),
    }
