import json
import os
import socket
import stat
import sys
import threading
import time
from pathlib import Path

from rpc import CodexReader, RpcError, RpcRequestError


sys.path.insert(0, str(
    Path(__file__).with_name("assets") / "websocket_client-1.9.0-py3-none-any.whl"
))
import websocket


def runtime_state(status, turn):
    kind = status.get("type")
    if kind == "active":
        if turn.get("status") != "inProgress":
            return None
        flags = status.get("activeFlags", [])
        if "waitingOnApproval" in flags:
            return "blocked", "等待你批准后继续执行。"
        if "waitingOnUserInput" in flags:
            return "blocked", "执行暂停，等待你回答交互问题。"
        return "in_progress", "AI 正在执行本轮任务。"
    if kind == "systemError":
        return "blocked", "执行遇到系统异常，需要处理后继续。"
    if turn.get("status") in {"failed", "interrupted"}:
        reason = "本轮请求失败，需要处理后重试。" if turn["status"] == "failed" else "本轮执行已中断，需要检查后继续。"
        return "blocked", reason
    if turn.get("status") == "completed":
        return "review", "本轮执行已结束，等待你审阅结果。"
    return None


def verified_socket(path):
    target = Path(path).resolve(strict=True)
    endpoint = target.stat()
    parent = target.parent.stat()
    if (
        not stat.S_ISSOCK(endpoint.st_mode)
        or endpoint.st_uid != os.getuid()
        or stat.S_IMODE(endpoint.st_mode) != 0o600
        or parent.st_uid != os.getuid()
        or stat.S_IMODE(parent.st_mode) != 0o700
    ):
        raise RpcError("桌面运行连接的所有者或权限无效")
    return str(target)


class DesktopReader:
    METHODS = {"initialize", "thread/list", "thread/turns/list"}
    list_threads = CodexReader.list_threads
    latest_turn = CodexReader.latest_turn

    def __init__(self, path, timeout=10):
        self.timeout = timeout
        self.request_id = 0
        transport = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        transport.settimeout(timeout)
        try:
            transport.connect(verified_socket(path))
            self.connection = websocket.create_connection(
                "ws://localhost/rpc", socket=transport, timeout=timeout
            )
            self.call("initialize", {
                "clientInfo": {"name": "session_board_runtime", "version": "0.2.5"}
            })
            self.connection.send(json.dumps({"method": "initialized"}))
        except Exception:
            transport.close()
            raise

    def call(self, method, params):
        if method not in self.METHODS:
            raise RpcError("运行观察器不允许修改 Codex 会话")
        self.request_id += 1
        deadline = min(
            time.monotonic() + self.timeout, getattr(self, "deadline", float("inf"))
        )
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise RpcError("读取桌面运行状态超时")
        self.connection.settimeout(remaining)
        self.connection.send(json.dumps({
            "id": self.request_id, "method": method, "params": params
        }))
        while time.monotonic() < deadline:
            self.connection.settimeout(max(0.01, deadline - time.monotonic()))
            message = json.loads(self.connection.recv())
            if time.monotonic() > deadline:
                break
            if "method" in message or message.get("id") != self.request_id:
                continue
            if "error" in message:
                raise RpcRequestError(f"{method}: {message['error'].get('message', '读取失败')}")
            return message["result"]
        raise RpcError("读取桌面运行状态超时")

    def close(self):
        self.connection.close()


class RuntimeObserver:
    def __init__(self, config, store, observer):
        self.config = config
        self.store = store
        self.observer = observer
        self.stop = threading.Event()
        self.revisions = {}
        self.started_at = time.time()

    def scan(self, reader):
        threads, complete = reader.list_threads(
            self.config["page_size"], self.config["max_pages"]
        )
        if not complete:
            raise RpcError("桌面运行状态分页未完成")
        self.store.discover(threads)
        unreadable = 0
        for thread in threads:
            if self.stop.is_set():
                return
            status = thread.get("status") or {}
            revision = (thread.get("updatedAt"), json.dumps(status, sort_keys=True))
            if status.get("type") != "active" and self.revisions.get(thread["id"]) == revision:
                continue
            try:
                turn = reader.latest_turn(thread["id"])
            except RpcRequestError:
                unreadable += 1
                continue
            if runtime_state(status, turn) is None:
                continue
            self.store.observe_runtime(thread["id"], status, turn, self.started_at)
            self.revisions[thread["id"]] = revision
        self.observer.update(
            runtimeVerified=True, runtimeLastAt=time.time(),
            runtimeError=f"{unreadable} 个会话的执行状态暂不可读" if unreadable else None,
        )

    def run(self):
        reader = None
        while not self.stop.is_set():
            try:
                if reader is None:
                    reader = DesktopReader(
                        self.config["desktop_socket"], self.config["rpc_timeout_seconds"]
                    )
                    self.revisions.clear()
                self.scan(reader)
            except (OSError, ValueError, RuntimeError, websocket.WebSocketException) as error:
                self.observer.update(runtimeVerified=False, runtimeError=str(error))
                if reader:
                    reader.close()
                    reader = None
            self.stop.wait(self.config["runtime_poll_seconds"])
        if reader:
            reader.close()
