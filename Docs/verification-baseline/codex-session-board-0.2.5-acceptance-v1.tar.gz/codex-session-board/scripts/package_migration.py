import argparse
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PATTERNS = (
    "*.py", "index.html", "config.example.json", "plugin.json", "mcp.json",
    ".mcp.json", ".codex-plugin/plugin.json", ".agents/plugins/marketplace.json",
    ".gitignore", "AGENTS.md", "README.md", "MIGRATION.md",
    "assets/*", "skills/**/*", "scripts/*.py", "scripts/*.sh",
    "ui/package.json", "ui/package-lock.json", "ui/bridge.js",
    "acceptance/*.py", "acceptance/README.md", "acceptance/requirements.json",
    "acceptance/bindings.json", "acceptance/contract.lock.json",
    "acceptance/evidence.example.json",
    "context/README.md", "context/PROJECT.yaml", "context/*/README.md",
    "context/tasks/*/README.md", "context/decisions/*.md",
)
FORBIDDEN_SUFFIXES = {".sqlite", ".sqlite3", ".db", ".log", ".png", ".pyc"}


def package_contents(root):
    contents = {}
    for pattern in PATTERNS:
        for path in root.glob(pattern):
            if not path.is_file():
                continue
            if path.is_symlink() or path.suffix in FORBIDDEN_SUFFIXES:
                raise ValueError(f"Not a portable source file: {path}")
            path.resolve().relative_to(root.resolve())
            contents[path.relative_to(root).as_posix()] = path.read_bytes()
    required = (
        "main.py", "mcp_server.py", "test_status.py", "MIGRATION.md",
        "acceptance/requirements.json", "acceptance/bindings.json",
        "acceptance/contract.lock.json", "acceptance/README.md",
        "assets/app-bridge.js", "assets/websocket_client-1.9.0-py3-none-any.whl",
    )
    if any(name not in contents for name in required):
        raise ValueError("Missing a required migration file")
    version = json.loads(contents["plugin.json"])["version"]
    if json.loads(contents[".codex-plugin/plugin.json"])["version"] != version:
        raise ValueError("Plugin manifest versions differ")
    current = json.loads((root / "context/STATE.yaml").read_bytes())
    date = current["updated_at"]
    contents["context/STATE.yaml"] = (json.dumps({
        "schema_version": 1, "updated_at": date,
        "current_phase": {
            "id": "migration-handoff", "status": "ready", "as_of": date,
            "summary": "Portable source and acceptance baseline. Live acceptance remains required.",
        },
        "active_tasks": [], "last_completed_task": None,
        "known_open_issues": current.get("known_open_issues", []),
        "verification": {
            "status": "pending", "last_checked_at": None,
            "method": "sh scripts/verify_context.sh",
            "boundary": "Project-local context files only.",
        },
    }, ensure_ascii=False, indent=2) + "\n").encode()
    manifest = {
        "schema_version": 1, "plugin_version": version,
        "files": {
            name: hashlib.sha256(body).hexdigest()
            for name, body in sorted(contents.items())
        },
    }
    contents["PACKAGE-MANIFEST.json"] = (
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    ).encode()
    return contents


def build_package(root, output):
    contents = package_contents(root)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as target, gzip.GzipFile(
        filename="", mode="wb", fileobj=target, mtime=0
    ) as compressed, tarfile.open(fileobj=compressed, mode="w") as archive:
        for name, body in sorted(contents.items()):
            entry = tarfile.TarInfo("codex-session-board/" + name)
            entry.size = len(body)
            entry.mode = 0o644
            archive.addfile(entry, io.BytesIO(body))
    checksum = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_name(output.name + ".sha256").write_text(
        f"{checksum}  {output.name}\n", encoding="utf-8"
    )
    return {"archive": str(output), "sha256": checksum, "files": len(contents)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build_package(args.root.resolve(), args.output.resolve())))


if __name__ == "__main__":
    main()
