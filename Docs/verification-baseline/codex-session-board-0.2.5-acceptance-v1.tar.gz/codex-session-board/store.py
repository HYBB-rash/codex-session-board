import json
import sqlite3
import threading
import time
from pathlib import Path


STATES = {
    "unknown": "待判断",
    "in_progress": "进行中",
    "review": "待审阅",
    "blocked": "已阻塞",
    "to_archive": "待归档",
    "completed": "已完成",
}


def recommend(turn):
    if turn.get("status") == "completed" and turn.get("hasFinal"):
        return "review", "最后一轮已结束并有最终答复，请检查是否需要验收或继续。"
    if turn.get("status") in {"failed", "interrupted"}:
        return "unknown", "历史记录显示本轮失败或未确认结束，不能据此断定任务已阻塞。"
    return "unknown", "尚无足够证据判断工作状态。"


def has_follow_up(row, turn):
    if row["selected_state"] is None or row["selected_at"] is None:
        return False
    if turn.get("id") == row["selection_turn"]:
        previous_users = set(json.loads(row["selection_users"]))
        return bool(set(turn.get("userItems", [])) - previous_users)
    started_at = turn.get("startedAt")
    return bool(
        turn.get("userItems")
        and started_at is not None
        and started_at > row["selected_at"]
    )


def suggested_state(row):
    suggestion, reason = recommend(json.loads(row["turn_json"]))
    if row["observed_revision"] is not None and row["updated_at"] > row["observed_revision"]:
        return "unknown", "会话有更新，等待重新读取历史。"
    return suggestion, reason


class Store:
    def __init__(self, directory, sync_titles=False):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.sync_titles = sync_titles
        self.title_callback = None
        self.database = sqlite3.connect(
            directory / "status.sqlite3", check_same_thread=False
        )
        self.database.row_factory = sqlite3.Row
        self.database.executescript("""
            CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                cwd TEXT NOT NULL,
                updated_at INTEGER NOT NULL,
                seen_at REAL NOT NULL,
                observed_at REAL,
                attempted_at REAL,
                observed_revision INTEGER,
                turn_json TEXT NOT NULL DEFAULT '{}',
                observation_error TEXT,
                selected_state TEXT,
                note TEXT NOT NULL DEFAULT '',
                selection_turn TEXT,
                selection_users TEXT NOT NULL DEFAULT '[]',
                selected_at REAL,
                runtime_key TEXT,
                automatic_state TEXT,
                automatic_reason TEXT,
                needs_review INTEGER NOT NULL DEFAULT 0,
                input_revision INTEGER NOT NULL DEFAULT 0,
                version INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS changes (
                sequence INTEGER PRIMARY KEY,
                thread_id TEXT NOT NULL,
                changed_at REAL NOT NULL,
                state TEXT,
                note TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS title_updates (
                thread_id TEXT PRIMARY KEY,
                version INTEGER NOT NULL,
                state TEXT NOT NULL,
                requested_at REAL NOT NULL,
                attempted_at REAL,
                error TEXT
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
        """)
        columns = {
            row["name"] for row in self.database.execute("PRAGMA table_info(sessions)")
        }
        if "needs_review" not in columns:
            self.database.execute(
                "ALTER TABLE sessions ADD COLUMN needs_review INTEGER NOT NULL DEFAULT 0"
            )
        if "input_revision" not in columns:
            self.database.execute(
                "ALTER TABLE sessions ADD COLUMN input_revision INTEGER NOT NULL DEFAULT 0"
            )
        for name in ("runtime_key", "automatic_state", "automatic_reason"):
            if name not in columns:
                self.database.execute(f"ALTER TABLE sessions ADD COLUMN {name} TEXT")
        self.title_epoch = None
        if self.sync_titles:
            self.database.execute(
                "INSERT OR IGNORE INTO settings(key, value) VALUES ('title_sync_started_at', ?)",
                (str(time.time()),),
            )
            self.title_epoch = float(self.database.execute(
                "SELECT value FROM settings WHERE key='title_sync_started_at'"
            ).fetchone()[0])
        self.database.commit()

    def close(self):
        self.database.close()

    def contains(self, thread_id):
        if not isinstance(thread_id, str):
            return False
        with self.lock:
            return self.database.execute(
                "SELECT 1 FROM sessions WHERE id=?", (thread_id,)
            ).fetchone() is not None

    def discover(self, threads):
        now = time.time()
        with self.lock, self.database:
            for thread in threads:
                title = thread.get("name") or thread.get("preview") or thread["id"]
                title = title.splitlines()[0][:300]
                self.database.execute("""
                    INSERT INTO sessions(id, title, cwd, updated_at, seen_at)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(id) DO UPDATE SET
                        title=excluded.title, cwd=excluded.cwd,
                        updated_at=excluded.updated_at, seen_at=excluded.seen_at
                """, (
                    thread["id"], title, thread.get("cwd", ""),
                    thread.get("updatedAt", 0), now,
                ))

    def observe(self, thread_id, turn, error=None):
        with self.lock, self.database:
            if error:
                self.database.execute(
                    "UPDATE sessions SET observation_error=?, attempted_at=? WHERE id=?",
                    (error, time.time(), thread_id),
                )
            else:
                row = self.database.execute(
                    "SELECT * FROM sessions WHERE id=?", (thread_id,)
                ).fetchone()
                if row is None:
                    return
                needs_review = row["needs_review"] or has_follow_up(row, turn)
                previous = json.loads(row["turn_json"])
                previous_users = set(previous.get("userItems", []))
                new_input = bool(
                    set(turn.get("userItems", [])) - previous_users
                    if turn.get("id") == previous.get("id")
                    else turn.get("userItems")
                )
                self.database.execute("""
                    UPDATE sessions SET turn_json=?, observed_at=?,
                        attempted_at=?, observed_revision=updated_at,
                        needs_review=?, input_revision=input_revision+?,
                        observation_error=NULL WHERE id=?
                """, (
                    json.dumps(turn), time.time(), time.time(),
                    bool(needs_review), int(new_input), thread_id,
                ))

    def pending(self):
        with self.lock:
            return [dict(row) for row in self.database.execute("""
                SELECT id, observed_at, attempted_at, observed_revision,
                    updated_at, turn_json, observation_error
                FROM sessions
                ORDER BY attempted_at IS NOT NULL, attempted_at ASC, updated_at DESC
            """)]

    def observe_runtime(self, thread_id, status, turn, observed_since=None):
        from runtime import runtime_state

        decision = runtime_state(status, turn)
        if decision is None or not turn.get("id"):
            return
        state, reason = decision
        flags = sorted(status.get("activeFlags", [])) if status.get("type") == "active" else []
        key = json.dumps([turn["id"], state, flags])
        with self.lock, self.database:
            row = self.database.execute(
                "SELECT * FROM sessions WHERE id=?", (thread_id,)
            ).fetchone()
            if row is None or row["runtime_key"] == key:
                return
            terminal = (
                status.get("type") not in {"active", "systemError"}
                and turn.get("status") in {"completed", "failed", "interrupted"}
            )
            event_at = turn.get("completedAt") if terminal else turn.get("startedAt")
            baseline = row["runtime_key"] is None
            preserve_manual = (
                row["selected_state"] is not None
                and (
                    baseline and (
                        turn["id"] == row["selection_turn"]
                        or event_at is None or event_at <= row["selected_at"]
                    )
                    or terminal and event_at is not None and event_at <= row["selected_at"]
                )
            )
            baseline_failure = (
                baseline and state == "blocked"
                and status.get("type") not in {"active", "systemError"}
                and (
                    observed_since is None or turn.get("startedAt") is None
                    or turn["startedAt"] < observed_since
                )
            )
            self.database.execute(
                "UPDATE sessions SET runtime_key=? WHERE id=?", (key, thread_id)
            )
            if preserve_manual or baseline_failure:
                return
            self.database.execute("""
                UPDATE sessions SET automatic_state=?, automatic_reason=?,
                    selected_state=NULL, needs_review=0, version=version+1
                WHERE id=?
            """, (state, reason, thread_id))
            self.database.execute(
                "INSERT INTO changes(thread_id, changed_at, state, note) VALUES (?, ?, ?, ?)",
                (thread_id, time.time(), state, reason),
            )
            live_change = (
                not baseline or status.get("type") in {"active", "systemError"}
                or observed_since is not None and turn.get("startedAt") is not None
                and turn["startedAt"] >= observed_since
            )
            if terminal and event_at is not None and self.title_epoch is not None and event_at < self.title_epoch:
                live_change = False
            sync_change = live_change or self.database.execute(
                "SELECT 1 FROM title_updates WHERE thread_id=?", (thread_id,)
            ).fetchone() is not None
            if sync_change:
                self._queue_title(thread_id)
        if sync_change and self.title_callback:
            self.title_callback(thread_id)

    def set_state(self, thread_id, state, note, expected_version, expected_input_version=None):
        if state is not None and state not in STATES:
            raise ValueError("未知状态")
        if not isinstance(note, str) or len(note) > 2000:
            raise ValueError("备注必须为不超过 2000 字的文本")
        if state == "blocked" and not note.strip():
            raise ValueError("请填写阻塞原因")
        with self.lock, self.database:
            row = self.database.execute(
                "SELECT * FROM sessions WHERE id=?", (thread_id,)
            ).fetchone()
            if row is None:
                raise KeyError("会话不存在")
            if row["version"] != expected_version:
                raise ValueError("状态已更新，请刷新后重试")
            if expected_input_version is not None and row["input_revision"] != expected_input_version:
                raise ValueError("会话有新输入，请刷新并核对后重试")
            turn = json.loads(row["turn_json"])
            now = time.time()
            self.database.execute("""
                UPDATE sessions SET selected_state=?, note=?, selection_turn=?,
                    selection_users=?, selected_at=?, needs_review=0,
                    version=version+1 WHERE id=?
            """, (
                state, note.strip(), turn.get("id"),
                json.dumps(turn.get("userItems", [])), now, thread_id,
            ))
            self.database.execute(
                "INSERT INTO changes(thread_id, changed_at, state, note) VALUES (?, ?, ?, ?)",
                (thread_id, now, state, note.strip()),
            )
            self._queue_title(thread_id)
        if self.title_callback:
            self.title_callback(thread_id)

    def _queue_title(self, thread_id):
        if not self.sync_titles:
            self.database.execute(
                "DELETE FROM title_updates WHERE thread_id=?", (thread_id,)
            )
            return
        row = self.database.execute(
            "SELECT * FROM sessions WHERE id=?", (thread_id,)
        ).fetchone()
        state = row["selected_state"] or row["automatic_state"] or suggested_state(row)[0]
        self.database.execute("""
            INSERT INTO title_updates(thread_id, version, state, requested_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(thread_id) DO UPDATE SET
                version=excluded.version, state=excluded.state,
                requested_at=excluded.requested_at, attempted_at=NULL, error=NULL
        """, (thread_id, row["version"], state, time.time()))

    def pending_titles(self, thread_id=None):
        with self.lock:
            query = "SELECT * FROM title_updates"
            arguments = ()
            if thread_id is not None:
                query += " WHERE thread_id=?"
                arguments = (thread_id,)
            query += " ORDER BY attempted_at IS NOT NULL, attempted_at, requested_at"
            return [dict(row) for row in self.database.execute(query, arguments)]

    def title_job_current(self, thread_id, version):
        with self.lock:
            return self.database.execute(
                """SELECT 1 FROM title_updates JOIN sessions ON sessions.id=title_updates.thread_id
                WHERE thread_id=? AND title_updates.version=? AND sessions.version=?""",
                (thread_id, version, version),
            ).fetchone() is not None

    def title_synced(self, thread_id, version, title):
        with self.lock, self.database:
            removed = self.database.execute(
                "DELETE FROM title_updates WHERE thread_id=? AND version=?",
                (thread_id, version),
            ).rowcount
            if removed:
                self.database.execute(
                    "UPDATE sessions SET title=? WHERE id=?", (title[:300], thread_id)
                )
            return bool(removed)

    def title_failed(self, thread_id, version, error):
        with self.lock, self.database:
            self.database.execute("""
                UPDATE title_updates SET attempted_at=?, error=?
                WHERE thread_id=? AND version=?
            """, (time.time(), error[:500], thread_id, version))

    def sessions(self):
        with self.lock:
            rows = self.database.execute(
                "SELECT * FROM sessions ORDER BY updated_at DESC, id"
            ).fetchall()
            title_jobs = {
                row["thread_id"]: dict(row)
                for row in self.database.execute("SELECT * FROM title_updates")
            }
        result = []
        for row in rows:
            turn = json.loads(row["turn_json"])
            suggestion, reason = suggested_state(row)
            selected = row["selected_state"]
            result.append({
                "id": row["id"],
                "title": row["title"],
                "cwd": row["cwd"],
                "updatedAt": row["updated_at"],
                "seenAt": row["seen_at"],
                "observedAt": row["observed_at"],
                "state": selected or row["automatic_state"] or suggestion,
                "manual": selected is not None,
                "suggestion": row["automatic_state"] or suggestion,
                "reason": row["automatic_reason"] or reason,
                "source": "manual" if selected else "runtime" if row["automatic_state"] else "history",
                "note": row["note"],
                "followUp": bool(row["needs_review"]),
                "observationError": row["observation_error"],
                "titleSyncPending": row["id"] in title_jobs,
                "titleSyncError": title_jobs.get(row["id"], {}).get("error"),
                "turnStatus": turn.get("status"),
                "version": row["version"],
                "inputVersion": row["input_revision"],
            })
        return result
