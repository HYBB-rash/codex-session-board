import json
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import parse_qs, urlsplit
from urllib.request import Request, urlopen
from unittest.mock import patch

from main import BUILD_ID, DEFAULTS, Observer, config_id, load_config, make_handler
from launcher import ensure_running, initialize_config, stop_running
from mcp_server import BoardBackend, MIME_TYPE, RESOURCE, dispatch, resource, tools
from navigation import conversation_url, open_conversation
from rpc import CodexReader, RpcError, RpcRequestError, summarize_turn
from store import Store, recommend
from runtime import DesktopReader, RuntimeObserver, runtime_state
from titles import DesktopTitleWriter, TitleSynchronizer, projected_title


def thread(thread_id="sample", updated=10):
    return {"id": thread_id, "name": "示例会话", "cwd": "/project", "updatedAt": updated}


def turn(turn_id="t1", status="completed", users=None, final=True, started=1):
    return {
        "id": turn_id, "status": status, "userItems": ["u1"] if users is None else users,
        "hasFinal": final, "startedAt": started,
    }


class FakeTitles:
    def __init__(self):
        self.title = "原始标题"
        self.writes = []
        self.error = None
        self.after_read = None
        self.after_write = None

    def writer(self, *_):
        return self

    def current_title(self, _):
        if self.after_read:
            callback, self.after_read = self.after_read, None
            callback()
        return self.title

    def rename(self, thread_id, title):
        if self.error:
            raise self.error
        self.title = title
        self.writes.append((thread_id, title))
        if self.after_write:
            callback, self.after_write = self.after_write, None
            callback()

    def close(self):
        return


class TitleTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.store = Store(self.directory.name, sync_titles=True)
        self.store.discover([thread()])
        self.native = FakeTitles()
        self.sync = TitleSynchronizer(
            {**DEFAULTS, "desktop_socket": "/configured"}, self.store, self.native.writer
        )
        self.store.title_callback = self.sync.sync

    def tearDown(self):
        self.store.close()
        self.directory.cleanup()

    def session(self):
        return self.store.sessions()[0]

    def select(self, state):
        self.store.set_state("sample", state, "保留备注", self.session()["version"])

    def test_prefix_replacement_is_idempotent_and_preserves_other_tags(self):
        for initial in ("[进行中] [待审阅] [Rust] 原标题", "【进行中】 [Rust] 原标题", "[Rust] 原标题"):
            self.assertEqual(projected_title(initial, "completed"), "[已完成] [Rust] 原标题")
        title = "[已完成] 标题中间 [进行中] 保持正文"
        self.assertEqual(projected_title(title, "review"), "[待审阅] 标题中间 [进行中] 保持正文")
        self.assertEqual(projected_title("[待审阅] 标题", "review"), "[待审阅] 标题")

    def test_saved_state_immediately_renames_and_fresh_native_body_is_preserved(self):
        self.select("completed")
        self.assertEqual(self.native.title, "[已完成] 原始标题")
        self.assertFalse(self.session()["titleSyncPending"])
        self.native.title = "[已完成] 我刚手动修改的标题" + "长" * 350
        self.select("to_archive")
        self.assertEqual(self.native.title, "[待归档] 我刚手动修改的标题" + "长" * 350)
        self.assertEqual(len(self.native.writes), 2)
        self.select("to_archive")
        self.assertEqual(len(self.native.writes), 2)

    def test_invalid_or_stale_edits_do_not_rename(self):
        with self.assertRaises(ValueError):
            self.store.set_state("sample", "blocked", "", 0)
        self.select("review")
        for arguments in (
            ("sample", "completed", "", 0),
            ("sample", "completed", "", self.session()["version"], -1),
        ):
            with self.assertRaises(ValueError):
                self.store.set_state(*arguments)
        self.assertEqual(len(self.native.writes), 1)

    def test_failure_keeps_saved_state_and_pending_work_survives_restart(self):
        self.native.error = TimeoutError("连接超时")
        self.select("completed")
        self.assertEqual(self.session()["state"], "completed")
        self.assertEqual(self.session()["note"], "保留备注")
        self.assertTrue(self.session()["titleSyncPending"])
        self.assertIn("超时", self.session()["titleSyncError"])
        self.store.close()
        self.store = Store(self.directory.name, sync_titles=True)
        self.native.error = None
        self.sync = TitleSynchronizer(DEFAULTS, self.store, self.native.writer)
        self.sync.config = {**DEFAULTS, "desktop_socket": "/configured"}
        worker = threading.Thread(target=self.sync.run, daemon=True)
        worker.start()
        try:
            deadline = time.monotonic() + 2
            while self.store.pending_titles() and time.monotonic() < deadline:
                self.sync.stop.wait(0.01)
            self.assertFalse(self.store.pending_titles())
            self.assertEqual(self.native.title, "[已完成] 原始标题")
        finally:
            self.sync.stop.set()
            self.sync.wake.set()
            worker.join(timeout=2)

    def test_remote_success_before_lost_ack_is_reconciled_without_duplicate_write(self):
        def lose_ack():
            raise TimeoutError("回执丢失")
        self.native.after_write = lose_ack
        self.select("review")
        self.assertTrue(self.session()["titleSyncPending"])
        self.sync.sync("sample")
        self.assertFalse(self.session()["titleSyncPending"])
        self.assertEqual(len(self.native.writes), 1)

    def test_newer_state_before_remote_write_replaces_old_job(self):
        self.native.after_read = lambda: self.select("review")
        self.select("in_progress")
        self.assertEqual(self.native.writes, [])
        self.assertEqual(self.store.pending_titles()[0]["state"], "review")
        self.sync.sync("sample")
        self.assertEqual(self.native.title, "[待审阅] 原始标题")

    def test_newer_state_during_write_is_not_deleted_by_old_ack(self):
        self.native.after_write = lambda: self.select("review")
        self.select("in_progress")
        self.assertEqual(self.store.pending_titles()[0]["state"], "review")
        self.sync.sync("sample")
        self.assertEqual(self.native.title, "[待审阅] 原始标题")
        self.assertFalse(self.store.pending_titles())

    def test_runtime_changes_sync_but_duplicate_stages_do_not(self):
        latest = turn(status="inProgress")
        for flags in ([], ["waitingOnApproval"], [], []):
            self.store.observe_runtime("sample", {"type": "active", "activeFlags": flags}, latest)
        self.store.observe_runtime("sample", {"type": "idle"}, turn())
        self.assertEqual(
            [title for _, title in self.native.writes],
            ["[进行中] 原始标题", "[已阻塞] 原始标题", "[进行中] 原始标题", "[待审阅] 原始标题"],
        )

    def test_discovery_history_and_initial_old_completion_do_not_bulk_rename(self):
        self.store.discover([thread(), thread("another")])
        self.store.observe("sample", turn())
        self.store.observe_runtime("sample", {"type": "idle"}, turn(), observed_since=time.time())
        self.assertEqual(self.native.writes, [])
        self.assertEqual(self.store.pending_titles(), [])

    def test_late_old_turn_change_does_not_rename_when_title_sync_is_first_enabled(self):
        ended = self.store.title_epoch - 1
        for identifier in ("old-cached", "old-latest"):
            latest = {**turn(identifier), "completedAt": ended}
            self.store.observe_runtime("sample", {"type": "idle"}, latest)
        self.assertEqual(self.native.writes, [])
        self.assertFalse(self.store.pending_titles())

    def test_title_activation_epoch_survives_restart_and_catches_new_completed_turn(self):
        epoch = self.store.title_epoch
        latest = {**turn("old"), "completedAt": epoch - 1}
        self.store.observe_runtime("sample", {"type": "idle"}, latest)
        self.store.close()
        self.store = Store(self.directory.name, sync_titles=True)
        self.assertEqual(self.store.title_epoch, epoch)
        latest = {**turn("new"), "completedAt": epoch + 1}
        self.store.observe_runtime("sample", {"type": "idle"}, latest)
        self.assertEqual(self.store.pending_titles()[0]["state"], "review")

    def test_sync_callback_runs_after_transaction_commits(self):
        self.native.after_read = lambda: self.assertFalse(self.store.database.in_transaction)
        self.select("review")
        self.assertEqual(self.native.title, "[待审阅] 原始标题")

    def test_busy_sync_does_not_hold_up_a_state_save(self):
        self.sync.lock.acquire()
        try:
            self.select("completed")
            self.assertTrue(self.session()["titleSyncPending"])
            self.assertTrue(self.sync.wake.is_set())
        finally:
            self.sync.lock.release()
        self.sync.sync("sample")
        self.assertFalse(self.session()["titleSyncPending"])

    def test_writer_allows_only_metadata_read_and_name_write(self):
        writer = DesktopTitleWriter.__new__(DesktopTitleWriter)
        for method in ("turn/start", "thread/archive", "thread/resume", "thread/goal/set"):
            with self.assertRaises(RpcError):
                writer.call(method, {})
        self.assertEqual(writer.METHODS, {"initialize", "thread/read", "thread/name/set"})
        writer.deadline = time.monotonic() - 1
        with self.assertRaisesRegex(RpcError, "超时"):
            writer.call("thread/read", {})

    def test_send_and_receive_share_the_same_absolute_title_deadline(self):
        clock = {"now": 0.0}
        timeouts = []

        class Connection:
            def settimeout(self, timeout):
                timeouts.append(timeout)

            def send(self, _):
                clock["now"] += 1.0

            def recv(self):
                clock["now"] = 3.1
                return json.dumps({"id": 1, "result": {}})

        writer = DesktopTitleWriter.__new__(DesktopTitleWriter)
        writer.deadline = 3.0
        writer.request_id = 0
        writer.connection = Connection()
        with patch("runtime.time.monotonic", side_effect=lambda: clock["now"]):
            with self.assertRaisesRegex(RpcError, "超时"):
                writer.call("thread/name/set", {"threadId": "sample", "name": "标题"})
        self.assertEqual(timeouts, [3.0, 2.0])

    def test_retry_batches_rotate_after_persistent_failures(self):
        self.store.title_callback = None
        identifiers = [f"retry-{number}" for number in range(21)]
        self.store.discover([thread(identifier) for identifier in identifiers])
        self.native.error = RpcError("仍然离线")
        for identifier in identifiers:
            self.store.set_state(identifier, "review", "", 0)
            self.sync.sync(identifier)
        attempts = []
        self.native.current_title = lambda identifier: attempts.append(identifier) or "标题"
        waits = []

        def stop_after_two(_):
            waits.append(True)
            if len(waits) == 2:
                self.sync.stop.set()

        with patch.object(self.sync.wake, "wait", side_effect=stop_after_two):
            self.sync.run()
        self.assertEqual(set(attempts), set(identifiers))


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.store = Store(self.directory.name)
        self.store.discover([thread()])

    def tearDown(self):
        self.store.close()
        self.directory.cleanup()

    def session(self):
        return self.store.sessions()[0]

    def test_discovery_is_automatic_idempotent_and_survives_restart(self):
        self.store.discover([thread(), thread()])
        self.store.close()
        self.store = Store(self.directory.name)
        self.assertEqual(len(self.store.sessions()), 1)
        self.assertEqual(self.session()["state"], "unknown")

    def test_success_requires_terminal_answer_to_suggest_review(self):
        self.assertEqual(recommend(turn(final=False))[0], "unknown")
        self.assertEqual(recommend(turn())[0], "review")
        for status in ("failed", "interrupted", "inProgress", "newStatus", None):
            self.assertEqual(recommend(turn(status=status))[0], "unknown")

    def test_assistant_updates_never_reopen_manual_completion(self):
        self.store.observe("sample", turn(status="inProgress"))
        self.store.set_state("sample", "completed", "验收通过", 0)
        self.store.observe("sample", turn())
        self.store.discover([thread(updated=20)])
        self.assertEqual(self.session()["state"], "completed")
        self.assertFalse(self.session()["followUp"])
        self.store.close()
        self.store = Store(self.directory.name)
        self.assertEqual(self.session()["note"], "验收通过")

    def test_same_turn_new_user_input_prompts_review_without_overwriting(self):
        self.store.observe("sample", turn())
        self.store.set_state("sample", "completed", "", 0)
        self.store.observe("sample", turn(users=["u1", "u2"]))
        self.assertTrue(self.session()["followUp"])
        self.assertEqual(self.session()["state"], "completed")

    def test_new_turn_requires_user_input_after_selection_boundary(self):
        self.store.observe("sample", turn())
        self.store.set_state("sample", "to_archive", "", 0)
        self.store.observe("sample", {**turn("maintenance"), "userItems": []})
        self.assertFalse(self.session()["followUp"])
        self.store.observe("sample", turn("late-replay", started=1))
        self.assertFalse(self.session()["followUp"])
        self.store.observe("sample", turn("t2", started=time.time() + 1))
        self.assertTrue(self.session()["followUp"])
        self.assertEqual(self.session()["state"], "to_archive")

    def test_manual_block_survives_success_and_failed_observation(self):
        self.store.observe("sample", turn())
        self.store.set_state("sample", "blocked", "等待资料", 0)
        self.store.observe("sample", turn("t2", status="inProgress"))
        self.store.observe("sample", {}, "connection lost")
        self.store.discover([])
        self.assertEqual(self.session()["state"], "blocked")
        self.assertEqual(self.session()["observationError"], "connection lost")

    def test_block_requires_reason_and_stale_edits_are_rejected(self):
        with self.assertRaises(ValueError):
            self.store.set_state("sample", "blocked", " ", 0)
        self.store.set_state("sample", "review", "", 0)
        with self.assertRaises(ValueError):
            self.store.set_state("sample", "completed", "", 0)
        self.store.set_state("sample", None, "", 1)
        self.assertFalse(self.session()["manual"])

    def test_summary_stores_identifiers_and_phase_without_message_text(self):
        result = summarize_turn({
            "id": "t1", "status": "completed", "items": [
                {"id": "u1", "type": "userMessage", "content": [{"text": "private"}]},
                {"id": "a1", "type": "agentMessage", "phase": "final_answer", "text": "private"},
            ],
        })
        self.assertEqual(result["userItems"], ["u1"])
        self.assertTrue(result["hasFinal"])
        self.assertNotIn("private", json.dumps(result))

    def test_new_activity_invalidates_cached_suggestion_until_history_is_read(self):
        self.store.observe("sample", turn())
        self.assertEqual(self.session()["state"], "review")
        self.store.discover([thread(updated=20)])
        self.assertEqual(self.session()["state"], "unknown")
        self.store.observe("sample", turn("t2"))
        self.assertEqual(self.session()["state"], "review")

    def test_new_input_notice_survives_automatic_turns_and_restart(self):
        self.store.observe("sample", turn())
        self.store.set_state("sample", "completed", "", 0)
        self.store.observe("sample", turn("t2", started=time.time() + 1))
        self.assertTrue(self.session()["followUp"])
        self.store.observe("sample", {**turn("automatic"), "userItems": []})
        self.assertTrue(self.session()["followUp"])
        self.store.close()
        self.store = Store(self.directory.name)
        self.assertTrue(self.session()["followUp"])
        self.store.set_state("sample", "completed", "新输入已核对", 1)
        self.assertFalse(self.session()["followUp"])

    def test_new_input_during_drag_rejects_stale_confirmation(self):
        self.store.observe("sample", turn())
        self.store.set_state("sample", "completed", "验收通过", 0)
        snapshot = self.session()
        self.store.observe("sample", turn(users=["u1", "u2"]))
        with self.assertRaisesRegex(ValueError, "新输入"):
            self.store.set_state(
                "sample", "to_archive", snapshot["note"],
                snapshot["version"], snapshot["inputVersion"],
            )
        self.assertEqual(self.session()["state"], "completed")
        self.assertTrue(self.session()["followUp"])
        self.assertEqual(self.session()["version"], snapshot["version"])

    def test_assistant_only_updates_do_not_invalidate_drag_input_version(self):
        self.store.observe("sample", turn(status="inProgress"))
        snapshot = self.session()
        self.store.observe("sample", turn())
        self.store.set_state(
            "sample", "review", "保留备注", snapshot["version"], snapshot["inputVersion"]
        )
        self.assertEqual(self.session()["note"], "保留备注")


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.store = Store(self.directory.name)
        self.store.discover([thread()])

    def tearDown(self):
        self.store.close()
        self.directory.cleanup()

    def session(self):
        return self.store.sessions()[0]

    def runtime(self, phase, turn_id="t1", flags=None):
        status = {"type": "active", "activeFlags": flags or []} if phase == "inProgress" else {"type": "idle"}
        latest = turn(turn_id, status=phase, started=time.time() + 1, final=False)
        self.store.observe_runtime("sample", status, latest)

    def test_execution_completion_and_next_reply_follow_runtime(self):
        self.runtime("inProgress")
        self.assertEqual(self.session()["state"], "in_progress")
        self.assertFalse(self.session()["manual"])
        self.runtime("completed")
        self.assertEqual(self.session()["state"], "review")
        self.store.set_state("sample", "completed", "验收通过", self.session()["version"])
        self.runtime("completed")
        self.assertEqual(self.session()["state"], "completed")
        self.runtime("inProgress", "t2")
        self.assertEqual(self.session()["state"], "in_progress")
        self.assertEqual(self.session()["note"], "验收通过")

    def test_repeated_approval_and_resume_in_one_turn(self):
        self.runtime("inProgress")
        for _ in range(2):
            self.runtime("inProgress", flags=["waitingOnApproval"])
            self.assertEqual(self.session()["state"], "blocked")
            self.assertIn("批准", self.session()["reason"])
            self.runtime("inProgress")
            self.assertEqual(self.session()["state"], "in_progress")
        self.runtime("completed")
        self.assertEqual(self.session()["state"], "review")

    def test_explicit_interaction_wait_is_blocked_but_plain_final_reply_is_review(self):
        self.runtime("inProgress", flags=["waitingOnUserInput"])
        self.assertEqual(self.session()["state"], "blocked")
        self.runtime("completed")
        self.assertEqual(self.session()["state"], "review")

    def test_failed_and_interrupted_execution_are_blocked(self):
        for phase in ("failed", "interrupted"):
            self.runtime("inProgress", phase)
            self.runtime(phase, phase)
            self.assertEqual(self.session()["state"], "blocked")
            self.assertFalse(self.session()["manual"])

    def test_first_observation_does_not_reclassify_old_failure(self):
        self.runtime("failed")
        self.assertEqual(self.session()["state"], "unknown")
        self.runtime("inProgress", "new")
        self.runtime("failed", "new")
        self.assertEqual(self.session()["state"], "blocked")

    def test_new_execution_that_fails_between_polls_is_still_blocked(self):
        started = time.time() + 1
        latest = {**turn(status="failed", started=started), "completedAt": started + 1}
        self.store.observe_runtime("sample", {"type": "idle"}, latest, observed_since=started - 1)
        self.assertEqual(self.session()["state"], "blocked")

    def test_manual_stage_override_survives_duplicate_snapshot_and_restart(self):
        self.runtime("inProgress")
        self.store.set_state("sample", "review", "人工检查", self.session()["version"])
        saved_version = self.session()["version"]
        self.runtime("inProgress")
        self.store.close()
        self.store = Store(self.directory.name)
        self.runtime("inProgress")
        self.assertEqual(self.session()["state"], "review")
        self.assertEqual(self.session()["version"], saved_version)
        self.runtime("inProgress", flags=["waitingOnApproval"])
        self.assertEqual(self.session()["state"], "blocked")

    def test_existing_manual_state_is_preserved_when_runtime_is_first_enabled(self):
        self.store.observe("sample", turn())
        self.store.set_state("sample", "to_archive", "收尾", 0)
        self.runtime("completed")
        self.assertEqual(self.session()["state"], "to_archive")
        self.runtime("inProgress", "new")
        self.assertEqual(self.session()["state"], "in_progress")

    def test_new_phase_rejects_a_stale_drag_without_erasing_manual_note(self):
        self.runtime("inProgress")
        saved = self.session()
        self.runtime("inProgress", flags=["waitingOnApproval"])
        with self.assertRaisesRegex(ValueError, "状态已更新"):
            self.store.set_state("sample", "completed", "", saved["version"])
        self.assertEqual(self.session()["state"], "blocked")

    def test_duplicate_phase_does_not_invalidate_manual_edit(self):
        self.runtime("inProgress")
        saved = self.session()
        self.runtime("inProgress")
        self.store.set_state("sample", "completed", "人工确认", saved["version"])
        self.runtime("completed")
        self.assertEqual(self.session()["state"], "review")
        self.assertEqual(self.session()["note"], "人工确认")

    def test_late_terminal_snapshot_does_not_override_a_later_manual_decision(self):
        for phase in ("completed", "failed", "interrupted"):
            self.runtime("inProgress", phase)
            ended = time.time() - 1
            self.store.set_state("sample", "completed", "已核对结果", self.session()["version"])
            saved_version = self.session()["version"]
            latest = {**turn(phase, status=phase), "completedAt": ended}
            self.store.observe_runtime("sample", {"type": "idle"}, latest)
            self.assertEqual(self.session()["state"], "completed")
            self.assertEqual(self.session()["version"], saved_version)

    def test_completion_after_manual_change_still_goes_to_review(self):
        self.runtime("inProgress")
        self.store.set_state("sample", "completed", "", self.session()["version"])
        latest = {**turn(), "completedAt": time.time() + 1}
        self.store.observe_runtime("sample", {"type": "idle"}, latest)
        self.assertEqual(self.session()["state"], "review")

    def test_stale_history_cannot_override_runtime_and_opening_does_not_write(self):
        self.runtime("inProgress")
        saved_version = self.session()["version"]
        self.store.observe("sample", turn())
        self.store.discover([thread(updated=20)])
        self.assertEqual(self.session()["state"], "in_progress")
        self.assertEqual(self.session()["version"], saved_version)

    def test_runtime_requires_consistent_active_turn_and_normal_end_needs_no_final(self):
        self.assertIsNone(runtime_state({"type": "active"}, turn()))
        self.assertEqual(runtime_state({"type": "idle"}, turn(final=False))[0], "review")
        self.assertEqual(runtime_state({"type": "systemError"}, turn())[0], "blocked")

    def test_runtime_observer_reads_owner_and_recovers_from_short_unseen_turn(self):
        observer = Observer(DEFAULTS, self.store)
        monitor = RuntimeObserver(DEFAULTS, self.store, observer)

        class Reader:
            def __init__(reader):
                reader.phase = "inProgress"
                reader.updated = 20

            def list_threads(reader, *_):
                status = {"type": "active", "activeFlags": []} if reader.phase == "inProgress" else {"type": "idle"}
                return [{**thread(updated=reader.updated), "status": status}], True

            def latest_turn(reader, _):
                return turn(str(reader.updated), status=reader.phase, final=False)

        reader = Reader()
        monitor.scan(reader)
        self.assertTrue(observer.snapshot()["runtimeVerified"])
        self.assertEqual(self.session()["state"], "in_progress")
        reader.phase = "completed"
        reader.updated = 30
        monitor.scan(reader)
        self.assertEqual(self.session()["state"], "review")

    def test_observer_connection_failure_does_not_mean_task_failure(self):
        self.runtime("inProgress")
        observer = Observer(DEFAULTS, self.store)
        monitor = RuntimeObserver({**DEFAULTS, "desktop_socket": "/missing"}, self.store, observer)
        with patch("runtime.DesktopReader", side_effect=RpcError("disconnected")):
            with patch.object(monitor.stop, "wait", side_effect=lambda _: monitor.stop.set()):
                monitor.run()
        self.assertEqual(self.session()["state"], "in_progress")
        self.assertFalse(observer.snapshot()["runtimeVerified"])
        self.assertEqual(observer.snapshot()["runtimeError"], "disconnected")

    def test_desktop_reader_cannot_write_to_codex(self):
        reader = DesktopReader.__new__(DesktopReader)
        for method in ("turn/start", "thread/archive", "thread/resume", "turn/interrupt"):
            with self.assertRaisesRegex(RpcError, "不允许修改"):
                reader.call(method, {})


class PaginationTests(unittest.TestCase):
    def reader(self, results):
        reader = CodexReader.__new__(CodexReader)
        iterator = iter(results)
        reader.call = lambda method, params: next(iterator)
        return reader

    def test_multiple_pages_are_deduplicated(self):
        reader = self.reader([
            {"data": [thread("a")], "nextCursor": "next"},
            {"data": [thread("a"), thread("b")], "nextCursor": None},
        ])
        sessions, complete = reader.list_threads()
        self.assertEqual([row["id"] for row in sessions], ["a", "b"])
        self.assertTrue(complete)

    def test_page_limit_is_disclosed_and_cursor_loops_fail(self):
        reader = self.reader([{"data": [thread()], "nextCursor": "next"}])
        self.assertFalse(reader.list_threads(max_pages=1)[1])
        reader = self.reader([{"data": [], "nextCursor": "same"}] * 2)
        with self.assertRaises(RpcError):
            reader.list_threads()

    def test_read_client_rejects_mutating_requests(self):
        reader = CodexReader.__new__(CodexReader)
        with self.assertRaises(RpcError):
            reader.call("turn/start", {})
        with self.assertRaises(RpcError):
            reader.call("thread/name/set", {})


class ObserverTests(unittest.TestCase):
    def test_repeated_timeout_cannot_starve_other_sessions(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(directory)
            store.discover([thread("broken"), thread("good")])
            store.observe("broken", turn())
            observer = Observer({**DEFAULTS, "history_per_poll": 2}, store)
            seen = []

            class Reader:
                def list_threads(self, *_):
                    return [thread("broken", updated=30), thread("good")], True

                def latest_turn(self, thread_id):
                    seen.append(thread_id)
                    if thread_id == "broken":
                        raise RpcError("timeout")
                    return turn()

            for _ in range(2):
                with self.assertRaises(RpcError):
                    observer.scan(Reader())
            self.assertEqual(seen[:2], ["broken", "good"])
            rows = {row["id"]: row for row in store.sessions()}
            self.assertEqual(rows["good"]["state"], "review")
            store.close()

    def test_changed_session_gets_priority_without_starving_backfill(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(directory)
            store.discover([thread("changed"), thread("old")])
            store.observe("changed", turn())
            config = {**DEFAULTS, "history_per_poll": 2}
            observer = Observer(config, store)
            seen = []

            class Reader:
                def list_threads(self, *_):
                    return [thread("changed", updated=30), thread("old")], True

                def latest_turn(self, thread_id):
                    seen.append(thread_id)
                    return turn()

            observer.scan(Reader())
            self.assertEqual(seen, ["changed", "old"])
            store.close()

    def test_one_unreadable_thread_does_not_block_remaining_histories(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(directory)
            observer = Observer(DEFAULTS, store)

            class Reader:
                def list_threads(self, *_):
                    return [thread("broken"), thread("good")], True

                def latest_turn(self, thread_id):
                    if thread_id == "broken":
                        raise RpcRequestError("history unavailable")
                    return turn()

            observer.scan(Reader())
            rows = {row["id"]: row for row in store.sessions()}
            self.assertIsNotNone(rows["broken"]["observationError"])
            self.assertEqual(rows["good"]["state"], "review")
            self.assertTrue(observer.snapshot()["scanComplete"])
            store.close()

    def test_connection_failure_preserves_previous_manual_state(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(directory)
            store.discover([thread()])
            store.set_state("sample", "completed", "", 0)
            observer = Observer(DEFAULTS, store)

            class Reader:
                def list_threads(self, *_):
                    raise RpcError("disconnected")

            with self.assertRaises(RpcError):
                observer.scan(Reader())
            self.assertEqual(store.sessions()[0]["state"], "completed")
            self.assertFalse(observer.snapshot()["scanComplete"])
            store.close()


class HttpTests(unittest.TestCase):
    def test_http_and_mcp_saves_sync_titles_and_report_pending_without_rollback(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(directory, sync_titles=True)
            store.discover([thread()])
            native = FakeTitles()
            sync = TitleSynchronizer(
                {**DEFAULTS, "desktop_socket": "/configured"}, store, native.writer
            )
            store.title_callback = sync.sync
            observer = Observer(DEFAULTS, store)
            server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(store, observer))
            worker = threading.Thread(target=server.serve_forever, daemon=True)
            worker.start()
            base = f"http://127.0.0.1:{server.server_port}"
            config = Path(directory) / "config.json"
            config.write_text(json.dumps({"data_dir": directory}))
            backend = BoardBackend(config)
            try:
                denied = Request(base + "/api/state", data=json.dumps({
                    "id": "sample", "state": "completed", "version": 0,
                }).encode())
                with self.assertRaises(HTTPError) as failure:
                    urlopen(denied)
                failure.exception.close()
                self.assertEqual(native.writes, [])
                with patch("mcp_server.ensure_running", return_value={"url": base}):
                    result = backend.call("board_update", {
                        "id": "sample", "state": "completed", "note": "验收",
                        "version": 0, "inputVersion": 0,
                    })
                    self.assertTrue(result["titleEnabled"])
                    self.assertFalse(result["titlePending"])
                    self.assertEqual(native.title, "[已完成] 原始标题")
                    native.error = TimeoutError("重命名超时")
                    result = backend.call("board_update", {
                        "id": "sample", "state": "review", "note": "继续检查",
                        "version": 1, "inputVersion": 0,
                    })
                    self.assertTrue(result["ok"])
                    self.assertTrue(result["titlePending"])
                    self.assertIn("超时", result["titleError"])
                    self.assertEqual(store.sessions()[0]["state"], "review")
                    self.assertEqual(store.sessions()[0]["note"], "继续检查")
                    with self.assertRaises(ValueError):
                        backend.call("board_update", {
                            "id": "sample", "state": "completed", "version": 1, "inputVersion": 0,
                        })
                    self.assertEqual(len(native.writes), 1)
            finally:
                server.shutdown()
                server.server_close()
                worker.join()
                store.close()

    def test_open_requires_authorization_and_known_thread_without_changing_state(self):
        thread_id = "11111111-1111-4111-8111-111111111111"
        opened = []
        with tempfile.TemporaryDirectory() as directory:
            store = Store(directory)
            store.discover([thread(thread_id)])
            observer = Observer(DEFAULTS, store)
            def opener(identifier, config):
                opened.append(identifier)
                return conversation_url(identifier, config["host_id"])
            server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(store, observer, opener))
            worker = threading.Thread(target=server.serve_forever, daemon=True)
            worker.start()
            base = f"http://127.0.0.1:{server.server_port}"
            try:
                with urlopen(base) as response:
                    token = response.read().decode().split('const csrf = "')[1].split('"')[0]
                request = Request(
                    base + "/api/open", data=json.dumps({"id": thread_id}).encode(),
                    headers={"Content-Type": "application/json"},
                )
                with self.assertRaises(HTTPError) as failure:
                    urlopen(request)
                self.assertEqual(failure.exception.code, 403)
                failure.exception.close()
                self.assertEqual(opened, [])
                request.add_header("X-CSRF-Token", token)
                with urlopen(request) as response:
                    self.assertTrue(json.load(response)["ok"])
                self.assertEqual(opened, [thread_id])
                request.data = json.dumps({"id": "22222222-2222-4222-8222-222222222222"}).encode()
                with self.assertRaises(HTTPError) as failure:
                    urlopen(request)
                self.assertEqual(failure.exception.code, 400)
                failure.exception.close()
                self.assertEqual(opened, [thread_id])
                self.assertEqual(store.sessions()[0]["version"], 0)
            finally:
                server.shutdown()
                server.server_close()
                worker.join()
                store.close()

    def test_real_http_edit_persistence_and_cross_origin_rejection(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(directory)
            store.discover([thread()])
            observer = Observer(DEFAULTS, store)
            server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(store, observer))
            worker = threading.Thread(target=server.serve_forever, daemon=True)
            worker.start()
            base = f"http://127.0.0.1:{server.server_port}"
            try:
                with urlopen(base) as response:
                    html = response.read().decode()
                token = html.split('const csrf = "')[1].split('"')[0]
                body = json.dumps({"id": "sample", "state": "completed", "version": 0}).encode()
                request = Request(base + "/api/state", data=body, headers={"Content-Type": "application/json"})
                with self.assertRaises(HTTPError) as failure:
                    urlopen(request)
                self.assertEqual(failure.exception.code, 403)
                failure.exception.close()
                request.add_header("X-CSRF-Token", token)
                request.add_header("Origin", "https://example.org")
                with self.assertRaises(HTTPError) as failure:
                    urlopen(request)
                failure.exception.close()
                request.remove_header("Origin")
                with urlopen(request) as response:
                    self.assertEqual(response.status, 200)
                with urlopen(base + "/api/sessions") as response:
                    result = json.load(response)
                self.assertEqual(result["sessions"][0]["state"], "completed")
                with self.assertRaises(HTTPError) as failure:
                    urlopen(Request(base, headers={"Host": "example.org"}))
                failure.exception.close()
            finally:
                server.shutdown()
                server.server_close()
                worker.join()
                store.close()
            store = Store(directory)
            self.assertEqual(store.sessions()[0]["state"], "completed")
            store.close()


class NavigationTests(unittest.TestCase):
    def test_deep_link_preserves_host_id_as_one_query_value(self):
        identifier = "11111111-1111-4111-8111-111111111111"
        host_id = "remote-ssh-codex-managed:host&value=one"
        parsed = urlsplit(conversation_url(identifier, host_id))
        self.assertEqual(parsed.scheme, "codex")
        self.assertEqual(parsed.netloc, "threads")
        self.assertEqual(parsed.path, "/" + identifier)
        self.assertEqual(parse_qs(parsed.query), {"hostId": [host_id]})

    def test_invalid_identifier_never_starts_a_process(self):
        with patch("navigation.subprocess.Popen") as process:
            for identifier in ("x; touch /tmp/test", "../other", None):
                with self.assertRaises(ValueError):
                    open_conversation(identifier, DEFAULTS)
            process.assert_not_called()

    def test_opener_uses_configured_client_and_surfaces_failure(self):
        identifier = "11111111-1111-4111-8111-111111111111"
        config = {**DEFAULTS, "open_command": ["chosen-client", "--existing"]}
        with patch("navigation.subprocess.Popen") as process:
            process.return_value.wait.return_value = 0
            url = open_conversation(identifier, config)
            self.assertEqual(process.call_args.args[0], ["chosen-client", "--existing", url])
            process.return_value.wait.return_value = 2
            with self.assertRaisesRegex(ValueError, "未接受"):
                open_conversation(identifier, config)


class McpTests(unittest.TestCase):
    def test_global_entrypoint_uses_ui_resource_and_app_only_actions(self):
        definitions = {tool["name"]: tool for tool in tools()}
        view = definitions.pop("board_view")
        self.assertEqual(view["_meta"]["ui"]["resourceUri"], RESOURCE)
        self.assertEqual(view["_meta"]["openai/ui"]["entrypoints"], [{"type": "global"}])
        self.assertTrue(view["icons"][0]["src"].startswith("data:image/svg+xml;base64,"))
        for definition in definitions.values():
            self.assertEqual(definition["_meta"]["ui"]["visibility"], ["app"])
            self.assertFalse(definition["annotations"]["openWorldHint"])

    def test_resource_is_self_contained_and_uses_bridge_not_http_embedding(self):
        result = resource()
        self.assertEqual(result["mimeType"], MIME_TYPE)
        self.assertIn("boardRequest", result["text"])
        self.assertIn("会话看板", result["text"])
        self.assertNotIn("<iframe", result["text"])
        self.assertNotIn("__CSRF_TOKEN__", result["text"])
        self.assertEqual(result["_meta"]["ui"]["csp"]["connectDomains"], [])
        with self.assertRaises(ValueError):
            dispatch("resources/read", {"uri": "https://other.invalid"}, None)

    def test_real_stdio_handshake_and_resource_discovery(self):
        requests = [
            {"jsonrpc": "2.0", "id": 0, "method": "initialize", "params": {"protocolVersion": "2025-06-18"}},
            {"jsonrpc": "2.0", "method": "notifications/initialized"},
            {"jsonrpc": "2.0", "id": 1, "method": "tools/list"},
            {"jsonrpc": "2.0", "id": 2, "method": "resources/list"},
        ]
        result = subprocess.run(
            [sys.executable, str(Path(__file__).with_name("mcp_server.py"))],
            input="\n".join(json.dumps(request) for request in requests) + "\n",
            capture_output=True, text=True, timeout=10, check=True,
        )
        responses = [json.loads(line) for line in result.stdout.splitlines()]
        self.assertEqual([response["id"] for response in responses], [0, 1, 2])
        self.assertEqual(responses[0]["result"]["protocolVersion"], "2025-06-18")
        self.assertEqual(responses[2]["result"]["resources"][0]["uri"], RESOURCE)

    def test_bridge_reuses_http_validation_and_never_sends_messages(self):
        identifier = "11111111-1111-4111-8111-111111111111"
        with tempfile.TemporaryDirectory() as directory:
            store = Store(directory)
            store.discover([thread(identifier)])
            opened = []
            def opener(thread_id, config):
                opened.append(thread_id)
                return conversation_url(thread_id)
            observer = Observer(DEFAULTS, store)
            server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(store, observer, opener))
            worker = threading.Thread(target=server.serve_forever, daemon=True)
            worker.start()
            config = Path(directory) / "config.json"
            config.write_text(json.dumps({"data_dir": directory}))
            backend = BoardBackend(config)
            try:
                base = f"http://127.0.0.1:{server.server_port}"
                with patch("mcp_server.ensure_running", return_value={"url": base}):
                    self.assertEqual(len(backend.call("board_snapshot", {})["sessions"]), 1)
                    update = {
                        "name": "board_update", "arguments": {
                            "id": identifier, "state": "completed", "note": "验收",
                            "version": 0, "inputVersion": 0,
                        },
                    }
                    self.assertFalse(dispatch("tools/call", update, backend).get("isError", False))
                    self.assertTrue(dispatch("tools/call", update, backend)["isError"])
                    backend.call("board_open", {"id": identifier})
                    self.assertEqual(opened, [identifier])
                    with self.assertRaises(ValueError):
                        backend.call("send_message", {})
                    self.assertEqual(store.sessions()[0]["note"], "验收")
                    self.assertEqual(store.sessions()[0]["version"], 1)
            finally:
                server.shutdown()
                server.server_close()
                worker.join()
                store.close()


class LauncherTests(unittest.TestCase):
    def test_migration_preserves_status_notes_and_does_not_overwrite_existing_config(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source_dir = root / "old"
            store = Store(source_dir)
            store.discover([thread()])
            store.set_state("sample", "blocked", "等待实际资料", 0)
            store.close()
            source_config = root / "source.json"
            source_config.write_text(json.dumps({"data_dir": str(source_dir)}))
            config_path = root / "config/config.json"
            target_dir = root / "new"
            initialize_config(config_path, target_dir, source_config, ["chosen-client"])
            migrated = Store(target_dir)
            self.assertEqual(migrated.sessions()[0]["state"], "blocked")
            self.assertEqual(migrated.sessions()[0]["note"], "等待实际资料")
            migrated.close()
            config = json.loads(config_path.read_text())
            self.assertEqual(config["open_command"], ["chosen-client"])
            with self.assertRaises(ValueError):
                initialize_config(config_path, target_dir, source_config)
            self.assertEqual(json.loads(config_path.read_text()), config)

    def test_launcher_reuses_matching_server_and_rejects_unrelated_service(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config_path = root / "config.json"
            config_path.write_text(json.dumps({"data_dir": directory}))
            info = {
                "app": "codex-session-board", "dataDir": directory,
                "build": BUILD_ID, "configId": config_id(load_config(config_path)),
            }
            with patch("launcher.probe", return_value=info), patch("launcher.subprocess.Popen") as process:
                self.assertFalse(ensure_running(config_path)["started"])
                process.assert_not_called()
            with patch("launcher.probe", return_value={"app": "other"}), patch("launcher.subprocess.Popen") as process:
                with self.assertRaises(ValueError):
                    ensure_running(config_path)
                process.assert_not_called()

    def test_stop_refuses_a_different_process(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config_path = root / "config.json"
            config_path.write_text(json.dumps({"data_dir": directory}))
            (root / "server.json").write_text(json.dumps({"pid": 111, "url": "http://127.0.0.1:8767"}))
            info = {"app": "codex-session-board", "dataDir": directory, "pid": 222}
            with patch("launcher.probe", return_value=info), patch("launcher.os.kill") as kill:
                with self.assertRaises(ValueError):
                    stop_running(config_path)
                kill.assert_not_called()

    def test_stop_waits_for_process_exit(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config_path = root / "config.json"
            config_path.write_text(json.dumps({"data_dir": directory}))
            (root / "server.json").write_text(json.dumps({
                "pid": 111, "url": "http://127.0.0.1:8767",
            }))
            info = {"app": "codex-session-board", "dataDir": directory, "pid": 111}
            with patch("launcher.probe", return_value=info), \
                    patch("launcher.os.kill"), patch("launcher.time.sleep"), \
                    patch("launcher.process_alive", side_effect=[True, True, False]) as alive:
                self.assertTrue(stop_running(config_path)["stopped"])
                self.assertEqual(alive.call_count, 3)

    def test_port_change_cannot_start_another_process(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config_path = root / "config.json"
            config_path.write_text(json.dumps({"data_dir": directory, "port": 8768}))
            (root / "server.json").write_text(json.dumps({
                "pid": 111, "url": "http://127.0.0.1:8767",
            }))
            info = {"app": "codex-session-board", "dataDir": directory, "pid": 111}
            with patch("launcher.probe", return_value=info), \
                    patch("launcher.subprocess.Popen") as process:
                with self.assertRaisesRegex(ValueError, "更换端口"):
                    ensure_running(config_path)
                process.assert_not_called()

    def test_changed_configuration_requires_restart(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config_path = root / "config.json"
            config_path.write_text(json.dumps({"data_dir": directory}))
            old_config = load_config(config_path)
            old_config["open_command"] = ["broken-client"]
            info = {
                "app": "codex-session-board", "dataDir": directory,
                "build": BUILD_ID, "configId": config_id(old_config),
            }
            with patch("launcher.probe", return_value=info), \
                    patch("launcher.subprocess.Popen") as process:
                with self.assertRaisesRegex(ValueError, "配置已变化"):
                    ensure_running(config_path)
                process.assert_not_called()

    def test_failed_config_write_rolls_back_only_new_database(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            store = Store(root / "old")
            store.discover([thread()])
            store.set_state("sample", "completed", "保留", 0)
            store.close()
            source = root / "source.json"
            source.write_text(json.dumps({"data_dir": str(root / "old")}))
            config_path = root / "config.json"
            target = root / "new"
            with patch("launcher.save_json", side_effect=PermissionError):
                with self.assertRaises(PermissionError):
                    initialize_config(config_path, target, source)
            self.assertFalse((target / "status.sqlite3").exists())
            self.assertTrue((root / "old/status.sqlite3").exists())
            initialize_config(config_path, target, source)
            migrated = Store(target)
            self.assertEqual(migrated.sessions()[0]["note"], "保留")
            migrated.close()


if __name__ == "__main__":
    unittest.main()
