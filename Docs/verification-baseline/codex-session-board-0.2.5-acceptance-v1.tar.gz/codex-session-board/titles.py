import re
import threading
import time

from rpc import RpcError
from runtime import DesktopReader
from store import STATES


PREFIX = re.compile(
    r"^(?:\[(?:" + "|".join(map(re.escape, STATES.values())) + r")\]"
    r"|【(?:" + "|".join(map(re.escape, STATES.values())) + r")】)\s*"
)


def projected_title(title, state):
    if state not in STATES:
        raise ValueError("未知状态")
    while PREFIX.match(title):
        title = PREFIX.sub("", title, count=1)
    return f"[{STATES[state]}] {title or '未命名会话'}"


class DesktopTitleWriter(DesktopReader):
    METHODS = {"initialize", "thread/read", "thread/name/set"}

    def __init__(self, path, timeout=3):
        self.deadline = time.monotonic() + min(timeout, 3)
        super().__init__(path, min(timeout, 1))

    def call(self, method, params):
        if method not in self.METHODS:
            raise RpcError("标题同步只允许读取标题和重命名")
        self.timeout = self.deadline - time.monotonic()
        if self.timeout <= 0:
            raise RpcError("标题同步超时，稍后重试")
        return super().call(method, params)

    def current_title(self, thread_id):
        thread = self.call("thread/read", {
            "threadId": thread_id, "includeTurns": False
        })["thread"]
        return thread.get("name") or (thread.get("preview") or thread_id).splitlines()[0]

    def rename(self, thread_id, title):
        self.call("thread/name/set", {"threadId": thread_id, "name": title})

    def close(self):
        self.connection.close(timeout=0.1)


class TitleSynchronizer:
    def __init__(self, config, store, writer_factory=DesktopTitleWriter):
        self.config = config
        self.store = store
        self.writer_factory = writer_factory
        self.lock = threading.Lock()
        self.stop = threading.Event()
        self.wake = threading.Event()

    def sync(self, thread_id, wait=False):
        if not self.lock.acquire(blocking=wait):
            self.wake.set()
            return
        writer = None
        try:
            jobs = self.store.pending_titles(thread_id)
            if not jobs or self.stop.is_set():
                return
            job = jobs[0]
            try:
                if not self.config["desktop_socket"]:
                    raise RpcError("未配置桌面连接，标题同步等待重试")
                writer = self.writer_factory(
                    self.config["desktop_socket"], self.config["rpc_timeout_seconds"]
                )
                current = writer.current_title(thread_id)
                target = projected_title(current, job["state"])
                if not self.store.title_job_current(thread_id, job["version"]):
                    self.wake.set()
                    return
                if current != target:
                    writer.rename(thread_id, target)
                if not self.store.title_synced(thread_id, job["version"], target):
                    self.wake.set()
            except Exception as error:
                self.store.title_failed(thread_id, job["version"], str(error))
        finally:
            if writer is not None:
                try:
                    writer.close()
                except Exception:
                    pass
            self.lock.release()

    def run(self):
        while not self.stop.is_set():
            self.wake.clear()
            for job in self.store.pending_titles()[:20]:
                if self.stop.is_set():
                    return
                self.sync(job["thread_id"], wait=True)
            if any(job["attempted_at"] is None for job in self.store.pending_titles()):
                self.wake.set()
            self.wake.wait(self.config["poll_seconds"])
