import { App } from "@modelcontextprotocol/ext-apps";

const app = new App(
  { name: "Codex session board", version: "0.2.0" },
  { availableDisplayModes: ["inline", "fullscreen"] },
  { autoResize: false },
);
const connected = app.connect();
const tools = {
  "/api/sessions": "board_snapshot",
  "/api/state": "board_update",
  "/api/open": "board_open",
  "/api/refresh": "board_refresh",
};

window.boardRequest = async (path, body) => {
  await connected;
  const name = tools[path];
  if (!name) throw new Error("未知看板操作");
  const result = await app.callServerTool({ name, arguments: body || {} });
  if (result.isError) {
    throw new Error(result.content?.find(item => item.type === "text")?.text || "操作失败");
  }
  if (result.structuredContent) return result.structuredContent;
  const content = result.content?.find(item => item.type === "text");
  if (!content) throw new Error("看板返回了空结果");
  return JSON.parse(content.text);
};
