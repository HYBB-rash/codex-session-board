import json
from pathlib import Path

from scripts.pr_task_state import ROOT, digest, git, locked, save


def registry():
    return Path(git(ROOT, "rev-parse", "--path-format=absolute", "--git-common-dir")) / "pr-queues"


def register(directory, state):
    with locked(registry()) as folder:
        for item in state["items"]:
            path = folder / f"{digest([state['repository'].lower(), item['number']])}.json"
            record = json.loads(path.read_text()) if path.exists() else {"directories": []}
            record["directories"] = sorted(set(record["directories"]) | {str(directory.resolve())})
            save(path, record)


def locate(repository, number):
    path = registry() / f"{digest([repository.lower(), number])}.json"
    record = json.loads(path.read_text())
    matches = []
    for name in record["directories"]:
        directory = Path(name).resolve(strict=True)
        state = json.loads((directory / "queue.json").read_text())
        if state["repository"].lower() != repository.lower():
            raise ValueError("Registered queue changed repository")
        item = next((item for item in state["items"] if item["number"] == number), None)
        if item is None:
            raise ValueError("Registered queue no longer contains this PR")
        matches.append((directory, item))
    active = [entry for entry in matches if entry[1]["status"] not in {"merged", "closed"}]
    selected = active or matches
    if len(selected) != 1:
        raise ValueError("Multiple queue records match; inspect their identities and select --state")
    return selected[0][0]
