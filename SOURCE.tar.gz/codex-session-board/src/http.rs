use crate::app::App;
use anyhow::{Context, Result, bail};
use serde_json::{Value, json};
use std::sync::Arc;
use tiny_http::{Header, Method, Request, Response, Server, StatusCode};

fn header<'request>(request: &'request Request, name: &str) -> Option<&'request str> {
    request
        .headers()
        .iter()
        .find(|header| header.field.as_str().as_str().eq_ignore_ascii_case(name))
        .map(|header| header.value.as_str())
}

pub fn authorized(
    host: Option<&str>,
    origin: Option<&str>,
    csrf: Option<&str>,
    token: &str,
    port: u16,
    writing: bool,
) -> bool {
    let authority = format!("127.0.0.1:{port}");
    host == Some(authority.as_str())
        && (!writing
            || csrf == Some(token)
                && origin.is_none_or(|origin| origin == format!("http://{authority}")))
}

fn response(request: Request, status: u16, body: String, content_type: &str) {
    let mut result = Response::from_string(body).with_status_code(StatusCode(status));
    for (name, value) in [
        ("Content-Type", content_type),
        ("Cache-Control", "no-store"),
        ("X-Content-Type-Options", "nosniff"),
        ("X-Frame-Options", "DENY"),
    ] {
        if let Ok(header) = Header::from_bytes(name, value) {
            result.add_header(header);
        }
    }
    let _ = request.respond(result);
}

fn json_response(request: Request, status: u16, body: Value) {
    response(
        request,
        status,
        body.to_string(),
        "application/json; charset=utf-8",
    );
}

fn body(request: &mut Request) -> Result<Value> {
    let length = request.body_length().context("请求大小无效")?;
    anyhow::ensure!(length > 0 && length <= 12000, "请求大小无效");
    let mut buffer = String::new();
    request
        .as_reader()
        .take(12001)
        .read_to_string(&mut buffer)?;
    anyhow::ensure!(buffer.len() <= 12000, "请求大小无效");
    let body: Value = serde_json::from_str(&buffer)?;
    anyhow::ensure!(body.is_object(), "请求格式无效");
    Ok(body)
}

pub fn info(app: &App) -> Result<Value> {
    crate::service::info(&app.config)
}

fn web_html(token: &str) -> String {
    include_str!("../index.html")
        .replace("__CSRF_TOKEN__", token)
        .replacen(
            "<title>",
            concat!(
                "<link rel=\"manifest\" href=\"/manifest.webmanifest\">\n",
                "<link rel=\"icon\" href=\"/assets/board.svg\" type=\"image/svg+xml\">\n",
                "<meta name=\"theme-color\" content=\"#32694b\">\n",
                "<script src=\"/assets/pwa.js\" defer></script>\n<title>"
            ),
            1,
        )
}

fn web_asset(path: &str) -> Option<(&'static str, &'static str)> {
    match path {
        "/manifest.webmanifest" => Some((
            include_str!("../assets/manifest.webmanifest"),
            "application/manifest+json; charset=utf-8",
        )),
        "/assets/board.svg" => Some((include_str!("../assets/board.svg"), "image/svg+xml")),
        "/assets/pwa.js" => Some((
            include_str!("../assets/pwa.js"),
            "text/javascript; charset=utf-8",
        )),
        "/sw.js" => Some((
            include_str!("../assets/sw.js"),
            "text/javascript; charset=utf-8",
        )),
        _ => None,
    }
}

pub fn handle(mut request: Request, app: &App, token: &str, port: u16) {
    let writing = request.method() != &Method::Get;
    if !authorized(
        header(&request, "Host"),
        header(&request, "Origin"),
        header(&request, "X-CSRF-Token"),
        token,
        port,
        writing,
    ) {
        return json_response(request, 403, json!({"error":"请从本地面板操作"}));
    }
    let path = request.url().split('?').next().unwrap_or("").to_string();
    if !writing && path == "/" {
        return response(request, 200, web_html(token), "text/html; charset=utf-8");
    }
    if !writing && let Some((body, content_type)) = web_asset(&path) {
        return response(request, 200, body.to_string(), content_type);
    }
    let result = if !writing && path == "/api/info" {
        info(app).map(|mut identity| {
            identity["requestToken"] = json!(token);
            identity
        })
    } else if request.method() == &Method::Post {
        body(&mut request).and_then(|body| app.request(&path, Some(&body)))
    } else if !writing {
        app.request(&path, None)
    } else {
        bail_result()
    };
    match result {
        Ok(value) => json_response(
            request,
            if path == "/api/refresh" { 202 } else { 200 },
            value,
        ),
        Err(error) => json_response(request, 400, json!({"error":error.to_string()})),
    }
}

fn bail_result() -> Result<Value> {
    bail!("不支持的请求方法")
}

pub fn bind(port: u16) -> Result<(Server, u16)> {
    let server = Server::http(("127.0.0.1", port)).map_err(|error| anyhow::anyhow!("{error}"))?;
    let actual_port = server.server_addr().to_ip().context("服务地址无效")?.port();
    Ok((server, actual_port))
}

pub fn run(server: Server, port: u16, app: Arc<App>) -> Result<()> {
    run_shared(Arc::new(server), port, app)
}

pub(crate) fn run_shared(server: Arc<Server>, port: u16, app: Arc<App>) -> Result<()> {
    let token = format!(
        "{}{}",
        uuid::Uuid::new_v4().simple(),
        uuid::Uuid::new_v4().simple()
    );
    let token = Arc::new(token);
    while app.enabled.load(std::sync::atomic::Ordering::SeqCst) {
        let Some(request) = server.recv_timeout(std::time::Duration::from_millis(100))? else {
            continue;
        };
        let worker = Arc::clone(&app);
        let token = Arc::clone(&token);
        if let Err(error) = app.workers.spawn(move || {
            handle(request, &worker, &token, port);
            Ok(())
        }) {
            if app.enabled.load(std::sync::atomic::Ordering::SeqCst) {
                return Err(error);
            }
            break;
        }
    }
    Ok(())
}

use std::io::Read;
