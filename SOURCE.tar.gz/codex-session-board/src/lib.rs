pub mod app;
pub mod archive;
pub mod auto_archive;
pub mod catalog;
pub mod config;
pub mod http;
pub mod mcp;
pub mod model;
pub mod native_sections;
mod native_new;
pub mod observer;
pub use app::preflight;
pub mod projects;
pub mod remote;
pub mod rpc;
mod runtime;
pub mod service;
#[cfg(target_os = "linux")]
pub mod singleton;
pub mod store;
pub mod titles;
mod workspaces;

#[cfg(test)]
mod formal;

mod workers;
