use crate::{config, runtime::RuntimeHandle};
use anyhow::{Context, Result, bail, ensure};
use base64::Engine;
use serde_json::{Value, json};
use std::io::{BufRead, Write};
use std::path::Path;

pub const RESOURCE: &str = "ui://session-board/index.html";
pub const MIME: &str = "text/html;profile=mcp-app";

pub fn tools() -> Value {
    tools_for(false)
}

pub fn tools_for(legacy: bool) -> Value {
    let mut tools = Vec::new();
    let icon =
        base64::engine::general_purpose::STANDARD.encode(include_bytes!("../assets/board.svg"));
    for (name, title, read_only) in [
        ("board_view", "会话看板", true),
        ("board_snapshot", "读取会话状态", true),
        ("board_update", "确认工作状态", false),
        ("board_sort", "设置栏目排序", false),
        ("board_archive", "归档待归档会话", false),
        ("board_open", "打开已有会话", true),
        ("board_new", "打开新建会话页", false),
        ("board_new_reset", "确认已核对新建结果", false),
        ("board_connect", "连接已登记的远程主机", false),
        ("board_refresh", "重新发现", false),
    ] {
        if legacy && matches!(name, "board_archive" | "board_new_reset" | "board_connect") {
            continue;
        }
        let (properties, required) = schema(name, legacy);
        let meta = if name == "board_view" {
            json!({"ui":{"resourceUri":RESOURCE,"visibility":["app","model"]},
                "openai/ui":{"entrypoints":[{"type":"global"}]}})
        } else {
            json!({"ui":{"visibility":["app"]}})
        };
        tools.push(json!({"name":name,"title":title,"description":title,
            "inputSchema":{"type":"object","properties":properties,"required":required,"additionalProperties":false},
            "annotations":{"readOnlyHint":read_only,"destructiveHint":name == "board_archive","openWorldHint":false},
            "icons":[{"src":format!("data:image/svg+xml;base64,{icon}"),"mimeType":"image/svg+xml"}],
            "_meta":meta}));
    }
    json!({"tools":tools})
}

fn schema(name: &str, legacy: bool) -> (Value, Value) {
    match name {
        "board_sort" => (
            json!({"state":{"type":"string","enum":crate::model::states_for(legacy).map(|item| item.0).collect::<Vec<_>>()},
                "field":{"type":"string","enum":["updated_at"]},
                "direction":{"type":"string","enum":["asc","desc"]},
                "version":{"type":"integer","minimum":0}}),
            json!(["state", "field", "direction", "version"]),
        ),
        "board_update" => (
            json!({
                "id":{"type":"string"}, "state":{"type":["string","null"],
                    "enum":crate::model::states_for(legacy).map(|item| json!(item.0)).chain([Value::Null]).collect::<Vec<_>>()},
                "note":{"type":"string","maxLength":2000},
                "sectionVersion":{"type":["string","null"]},
                "version":{"type":"integer","minimum":0},"inputVersion":{"type":"integer","minimum":0}
            }),
            json!(["id", "state", "version", "inputVersion"]),
        ),
        "board_open" => (json!({"id":{"type":"string"}}), json!(["id"])),
        "board_connect" => (json!({"hostId":{"type":"string"}}), json!(["hostId"])),
        "board_archive" => (
            json!({"id":{"type":"string"},"version":{"type":"integer","minimum":0},
                "inputVersion":{"type":"integer","minimum":0},"sectionVersion":{"type":["string","null"]}}),
            json!(["id", "version", "inputVersion"]),
        ),
        "board_new" => (
            json!({"projectId":{"type":"string"},"requestId":{"type":"string"},
            "hostId":{"type":"string"}}),
            json!([]),
        ),
        "board_new_reset" => (
            json!({"projectId":{"type":"string"},
            "requestId":{"type":"string"},"confirmed":{"type":"boolean","const":true}}),
            json!(["projectId", "requestId", "confirmed"]),
        ),
        _ => (json!({}), json!([])),
    }
}

pub fn resource() -> Value {
    let bridge = include_str!("../assets/app-bridge.js")
        .replace(
            "\"/api/refresh\":\"board_refresh\"",
            "\"/api/refresh\":\"board_refresh\",\"/api/new\":\"board_new\",\"/api/new/reset\":\"board_new_reset\",\"/api/connect\":\"board_connect\",\"/api/archive\":\"board_archive\",\"/api/column-sort\":\"board_sort\"",
        )
        .replace("</script", "<\\/script");
    let html = include_str!("../index.html")
        .replace("__CSRF_TOKEN__", "")
        .replacen(
            "<script>",
            &format!("<script>{bridge}</script>\n<script>"),
            1,
        );
    json!({"uri":RESOURCE,"mimeType":MIME,"text":html,
        "_meta":{"ui":{"prefersBorder":false,"csp":{"connectDomains":[],"resourceDomains":[],"frameDomains":[]}},
        "openai/ui":{"preferredDisplayMode":"fullscreen","availableDisplayModes":["inline","fullscreen"]}}})
}

fn backend(runtime: &mut RuntimeHandle, name: &str, arguments: &Value) -> Result<Value> {
    if name == "board_view" {
        return Ok(json!({"ready":true}));
    }
    let path = match name {
        "board_snapshot" => "/api/sessions",
        "board_update" => "/api/state",
        "board_sort" => "/api/column-sort",
        "board_archive" => "/api/archive",
        "board_open" => "/api/open",
        "board_new" => "/api/new",
        "board_new_reset" => "/api/new/reset",
        "board_connect" => "/api/connect",
        "board_refresh" => "/api/refresh",
        _ => bail!("未知看板工具"),
    };
    runtime.request(path, (name != "board_snapshot").then_some(arguments))
}

fn dispatch(method: &str, params: &Value, runtime: &mut RuntimeHandle) -> Result<Value> {
    match method {
        "initialize" => Ok(
            json!({"protocolVersion":params["protocolVersion"].as_str().unwrap_or("2025-06-18"),
            "capabilities":{"tools":{},"resources":{}},
            "serverInfo":{"name":"codex-session-board","version":env!("CARGO_PKG_VERSION")},
            "instructions":"会话看板。不发送消息或执行任务。功能取决于配置模式和主机连接状态；已连接的本地与远程会话共用状态、标题及归档逻辑。"}),
        ),
        "ping" => Ok(json!({})),
        "tools/list" => {
            Ok(tools_for(runtime.legacy()))
        }
        "resources/list" => {
            Ok(json!({"resources":[{"uri":RESOURCE,"name":"会话看板","mimeType":MIME}]}))
        }
        "resources/templates/list" => Ok(json!({"resourceTemplates":[]})),
        "resources/read" => {
            ensure!(params["uri"] == RESOURCE, "未知界面资源");
            Ok(json!({"contents":[resource()]}))
        }
        "tools/call" => Ok(
            match backend(
                runtime,
                params["name"].as_str().context("缺少工具名称")?,
                params.get("arguments").unwrap_or(&json!({})),
            ) {
                Ok(value) => {
                    json!({"content":[{"type":"text","text":value.to_string()}],"structuredContent":value})
                }
                Err(error) => {
                    json!({"isError":true,"content":[{"type":"text","text":error.to_string()}]})
                }
            },
        ),
        _ => bail!("Unknown method: {method}"),
    }
}

pub fn serve(path: Option<&Path>) -> Result<()> {
    let entry = config::entry_path()?;
    let path = path.unwrap_or(&entry);
    let mut runtime = RuntimeHandle::load(path)?;
    for line in std::io::stdin().lock().lines() {
        let result = answer(&line?, &mut runtime);
        if let Some(response) = result {
            writeln!(std::io::stdout().lock(), "{response}")?;
            std::io::stdout().flush()?;
        }
    }
    runtime.shutdown()
}

fn answer(line: &str, runtime: &mut RuntimeHandle) -> Option<Value> {
    let parsed = serde_json::from_str::<Value>(line);
    let request = match parsed {
        Ok(request) => request,
        Err(error) => {
            return Some(
                json!({"jsonrpc":"2.0","id":null,"error":{"code":-32700,"message":error.to_string()}}),
            );
        }
    };
    let identifier = request.get("id")?;
    let params = request.get("params").cloned().unwrap_or(json!({}));
    Some(
        match dispatch(request["method"].as_str().unwrap_or(""), &params, runtime) {
            Ok(result) => json!({"jsonrpc":"2.0","id":identifier,"result":result}),
            Err(error) => {
                json!({"jsonrpc":"2.0","id":identifier,"error":{"code":-32602,"message":error.to_string()}})
            }
        },
    )
}
